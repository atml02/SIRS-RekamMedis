<?php

$config['error_prefix'] = '<small class="text-danger">';
$config['error_suffix'] = '</small>';
