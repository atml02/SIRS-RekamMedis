###################
HALLO
###################

Ini Adalah  Aplikasi Rekam Medis. Yamg Dibangun Dengan Menggunakan Bootstrap dan CodeIgnater.
Aplikasi ini dibuat pada dasar nya untuk menyelesaikan Program Kerja Lapangan kuliah.
Apliksi yang dibangun adalah aplikasi Rekam Medis Rumah Sakit yang berbasis website�..
Aplikasi yang jauh dari kata sempurna.Masih Banyak Hal yang harus Dilengkapi dalam aplikasi Ini

*******************
Biodata Diri
*******************

Nama	:Chairul Hamid
Alamat	:Bukittinggi,Sumatera Barat
Ig	:Chairul.hamid_



**************************
Tiada Hari Tanpa Belajar.
**************************


**************************
FOLLOW Me!!
**************************



