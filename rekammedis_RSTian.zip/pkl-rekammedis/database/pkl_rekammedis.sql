-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 16 Bulan Mei 2024 pada 05.23
-- Versi server: 10.1.37-MariaDB
-- Versi PHP: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pkl_rekammedis`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_imunisasi`
--

CREATE TABLE `data_imunisasi` (
  `id` int(11) NOT NULL,
  `namakk` varchar(30) NOT NULL,
  `nokartu` varchar(25) NOT NULL,
  `namaP` varchar(30) NOT NULL,
  `jeniskel` varchar(25) NOT NULL,
  `umurP` varchar(25) NOT NULL,
  `alamatP` varchar(30) NOT NULL,
  `jenisk` text NOT NULL,
  `tggl` date NOT NULL,
  `jam` time(4) NOT NULL,
  `nama` text NOT NULL,
  `tggalhr` date NOT NULL,
  `umur` varchar(25) NOT NULL,
  `alamat` varchar(128) NOT NULL,
  `pekerjn` text NOT NULL,
  `keluhan` varchar(128) NOT NULL,
  `tnggi` int(25) NOT NULL,
  `berat` decimal(10,2) NOT NULL,
  `lper` decimal(10,2) NOT NULL,
  `imt` decimal(10,2) NOT NULL,
  `suhu` decimal(10,2) NOT NULL,
  `sistole` decimal(10,2) NOT NULL,
  `distole` decimal(10,2) NOT NULL,
  `rrt` decimal(10,2) NOT NULL,
  `hrt` decimal(10,2) NOT NULL,
  `hb` decimal(10,2) NOT NULL,
  `gdarah` decimal(10,2) NOT NULL,
  `pdarah` decimal(10,2) NOT NULL,
  `diagnosa` text NOT NULL,
  `pengo` varchar(128) NOT NULL,
  `konsl` varchar(128) NOT NULL,
  `rujuk` text NOT NULL,
  `tenagam` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `data_imunisasi`
--

INSERT INTO `data_imunisasi` (`id`, `namakk`, `nokartu`, `namaP`, `jeniskel`, `umurP`, `alamatP`, `jenisk`, `tggl`, `jam`, `nama`, `tggalhr`, `umur`, `alamat`, `pekerjn`, `keluhan`, `tnggi`, `berat`, `lper`, `imt`, `suhu`, `sistole`, `distole`, `rrt`, `hrt`, `hb`, `gdarah`, `pdarah`, `diagnosa`, `pengo`, `konsl`, `rujuk`, `tenagam`) VALUES
(2, 'Test', '976', 'bassi', 'perempuan', '32', '---', 'Baru', '2020-09-06', '12:30:00.0000', '', '0000-00-00', '', '', '', 'Kosong', 0, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 'Diagnosa tidak di pilih', 'Kosong', 'Kosong', 'Tidak', 'Tenaga medis tidak di pilih');

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_kabe`
--

CREATE TABLE `data_kabe` (
  `id` int(255) NOT NULL,
  `namakk` varchar(30) NOT NULL,
  `nokartu` varchar(25) NOT NULL,
  `namaP` varchar(30) NOT NULL,
  `jeniskel` varchar(25) NOT NULL,
  `umurP` varchar(25) NOT NULL,
  `alamatP` varchar(30) NOT NULL,
  `jenisk` text NOT NULL,
  `tggl` date NOT NULL,
  `jam` int(4) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `tggalhr` date NOT NULL,
  `umur` int(25) NOT NULL,
  `pendidikan` text NOT NULL,
  `pekerjn` varchar(128) NOT NULL,
  `alamat` varchar(128) NOT NULL,
  `nmsuami` text NOT NULL,
  `umsuami` varchar(25) NOT NULL,
  `pensuami` varchar(128) NOT NULL,
  `peksuami` int(128) NOT NULL,
  `jmlhank` int(25) NOT NULL,
  `haidt` date NOT NULL,
  `rwkb` text NOT NULL,
  `rwkb2` date NOT NULL,
  `keluhan` varchar(128) NOT NULL,
  `tnggi` int(12) NOT NULL,
  `berat` decimal(10,2) NOT NULL,
  `lper` decimal(10,2) NOT NULL,
  `imt` decimal(10,2) NOT NULL,
  `suhu` decimal(10,2) NOT NULL,
  `sistole` decimal(10,2) NOT NULL,
  `distole` decimal(10,2) NOT NULL,
  `rrt` decimal(10,2) NOT NULL,
  `hrt` decimal(10,2) NOT NULL,
  `hb` decimal(10,2) NOT NULL,
  `uralbu` decimal(10,2) NOT NULL,
  `urredu` decimal(10,2) NOT NULL,
  `diagnosa` text NOT NULL,
  `pengo` varchar(128) NOT NULL,
  `konsl` varchar(128) NOT NULL,
  `rujuk` text NOT NULL,
  `tenagam` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `data_kabe`
--

INSERT INTO `data_kabe` (`id`, `namakk`, `nokartu`, `namaP`, `jeniskel`, `umurP`, `alamatP`, `jenisk`, `tggl`, `jam`, `nama`, `tggalhr`, `umur`, `pendidikan`, `pekerjn`, `alamat`, `nmsuami`, `umsuami`, `pensuami`, `peksuami`, `jmlhank`, `haidt`, `rwkb`, `rwkb2`, `keluhan`, `tnggi`, `berat`, `lper`, `imt`, `suhu`, `sistole`, `distole`, `rrt`, `hrt`, `hb`, `uralbu`, `urredu`, `diagnosa`, `pengo`, `konsl`, `rujuk`, `tenagam`) VALUES
(2, 'Test', '643', 'andi', 'laki_laki', '13', '---', 'Baru', '2020-09-06', 12, '', '0000-00-00', 0, '', '', '', '', '', '', 0, 0, '0000-00-00', 'Tidak', '0000-00-00', '', 0, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 'Diagnosa tidak di pilih', '', '', 'Tidak', 'Tenaga medis tidak di pilih');

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_poli_anak`
--

CREATE TABLE `data_poli_anak` (
  `id` int(255) NOT NULL,
  `namakk` varchar(30) NOT NULL,
  `nokartu` varchar(25) NOT NULL,
  `namaP` varchar(30) NOT NULL,
  `jeniskel` varchar(25) NOT NULL,
  `umurP` varchar(25) NOT NULL,
  `alamatP` varchar(30) NOT NULL,
  `jenisk` text NOT NULL,
  `tggl` date NOT NULL,
  `jam` time(4) NOT NULL,
  `nama` text NOT NULL,
  `jenkel` text NOT NULL,
  `tggalhr` date NOT NULL,
  `umur` varchar(25) NOT NULL,
  `alamat` varchar(128) NOT NULL,
  `nmayh` text NOT NULL,
  `umayh` varchar(25) NOT NULL,
  `penayh` text NOT NULL,
  `pkayh` text NOT NULL,
  `nmibu` text NOT NULL,
  `umibu` varchar(25) NOT NULL,
  `penibu` text NOT NULL,
  `pkibu` text NOT NULL,
  `bbdn_a` int(8) NOT NULL,
  `prol` text NOT NULL,
  `letjan` text NOT NULL,
  `klahir` text NOT NULL,
  `konbay` text NOT NULL,
  `kesimpulanby` text NOT NULL,
  `bbdn_b` decimal(10,2) NOT NULL,
  `penap` decimal(10,2) NOT NULL,
  `konasi` text NOT NULL,
  `gejala` text NOT NULL,
  `kesimpulan` text NOT NULL,
  `bbdn_c` decimal(10,2) NOT NULL,
  `ketbb` text NOT NULL,
  `dimun` text NOT NULL,
  `pernap` decimal(10,2) NOT NULL,
  `gejalan` text NOT NULL,
  `makanbayi` text NOT NULL,
  `kesimpulanneo` text NOT NULL,
  `keluhan` varchar(128) NOT NULL,
  `berat` decimal(10,2) NOT NULL,
  `suhu` decimal(10,2) NOT NULL,
  `rrt` decimal(10,2) NOT NULL,
  `hrt` decimal(10,2) NOT NULL,
  `diagnosa` text NOT NULL,
  `pengo` varchar(256) NOT NULL,
  `konsl` varchar(256) NOT NULL,
  `rujuk` text NOT NULL,
  `tenagam` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `data_poli_anak`
--

INSERT INTO `data_poli_anak` (`id`, `namakk`, `nokartu`, `namaP`, `jeniskel`, `umurP`, `alamatP`, `jenisk`, `tggl`, `jam`, `nama`, `jenkel`, `tggalhr`, `umur`, `alamat`, `nmayh`, `umayh`, `penayh`, `pkayh`, `nmibu`, `umibu`, `penibu`, `pkibu`, `bbdn_a`, `prol`, `letjan`, `klahir`, `konbay`, `kesimpulanby`, `bbdn_b`, `penap`, `konasi`, `gejala`, `kesimpulan`, `bbdn_c`, `ketbb`, `dimun`, `pernap`, `gejalan`, `makanbayi`, `kesimpulanneo`, `keluhan`, `berat`, `suhu`, `rrt`, `hrt`, `diagnosa`, `pengo`, `konsl`, `rujuk`, `tenagam`) VALUES
(5, 'Jhon Doe', '000011', 'Dibala', 'Laki-Laki', '7', 'Padang Lua', 'Baru', '2020-09-06', '07:56:42.8970', '', '', '2000-09-10', '22', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '0.00', '0.00', '', '', '', '0.00', '', '', '0.00', '', '', '', 'kosong', '0.00', '0.00', '0.00', '0.00', 'Sehat', 'Kosong', 'Kosong', 'Tidak', 'Dokter'),
(7, 'Andri', '0100100', 'Billiy', 'perempuan', '', '', 'Baru', '2021-01-13', '01:57:00.0000', '', '--', '0000-00-00', '20', 'Padang Luar', '', '', '', '', '', '', '', '', 0, '--', '--', '--', '--', '--', '0.00', '0.00', '--', '--', '--', '0.00', '--', '--', '0.00', '--', '--', '--', '', '0.00', '0.00', '0.00', '0.00', 'Diagnosa tidak di pilih', '', '', 'Tidak', 'Tenaga Medis Tidak Dipilih '),
(8, 'Andri', '0100100', 'Billiy', 'perempuan', '', '', 'Baru', '2020-11-14', '11:15:00.0000', '', '--', '0000-00-00', '20', 'Padang Luar', '', '', '', '', '', '', '', '', 0, '--', '--', '--', '--', '--', '0.00', '0.00', '--', '--', '--', '0.00', '--', '--', '0.00', '--', '--', '--', '', '0.00', '0.00', '0.00', '0.00', 'Diagnosa tidak di pilih', '', '', 'Tidak', 'Tenaga Medis Tidak Dipilih ');

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_poli_gigi`
--

CREATE TABLE `data_poli_gigi` (
  `id` int(255) NOT NULL,
  `namakk` varchar(30) NOT NULL,
  `nokartu` varchar(25) NOT NULL,
  `namaP` varchar(30) NOT NULL,
  `jeniskel` varchar(25) NOT NULL,
  `umur` varchar(25) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `jenisk` text NOT NULL,
  `tggl` date NOT NULL,
  `jam` time(4) NOT NULL,
  `keluhan` text NOT NULL,
  `tnggi` int(25) NOT NULL,
  `berat` decimal(10,2) NOT NULL,
  `lper` decimal(25,0) NOT NULL,
  `imt` decimal(10,2) NOT NULL,
  `suhu` decimal(10,2) NOT NULL,
  `sistole` decimal(10,2) NOT NULL,
  `distole` decimal(10,2) NOT NULL,
  `rrt` decimal(10,2) NOT NULL,
  `hrt` decimal(10,2) NOT NULL,
  `hb` decimal(10,2) NOT NULL,
  `gdarah` decimal(10,2) NOT NULL,
  `pdarah` decimal(10,2) NOT NULL,
  `diagnosa` text NOT NULL,
  `pengo` varchar(128) NOT NULL,
  `konsl` varchar(128) NOT NULL,
  `rujuk` text NOT NULL,
  `tenagam` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `data_poli_gigi`
--

INSERT INTO `data_poli_gigi` (`id`, `namakk`, `nokartu`, `namaP`, `jeniskel`, `umur`, `alamat`, `jenisk`, `tggl`, `jam`, `keluhan`, `tnggi`, `berat`, `lper`, `imt`, `suhu`, `sistole`, `distole`, `rrt`, `hrt`, `hb`, `gdarah`, `pdarah`, `diagnosa`, `pengo`, `konsl`, `rujuk`, `tenagam`) VALUES
(3, 'Test', '9754454', 'weri', 'Laki-Laki', '12', '---', 'Baru', '2020-09-12', '12:39:00.0000', 'Coba', 170, '90.00', '99', '26.47', '75.00', '120.00', '70.00', '180.00', '123.00', '12.00', '12.00', '12.00', 'Sehat', 'Kosong', 'Kosong', 'Tidak', 'Yulia Safitri Amd.Keb S.Ter Keb'),
(4, 'selamat', '0985', 'andi', 'laki_laki', '13', 'Padang lua', 'Baru', '2024-05-16', '09:39:00.0000', '', 0, '0.00', '0', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', ' Kholera\r\n', '', '', 'Tidak', 'Dr.Cahyono');

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_poli_ibu`
--

CREATE TABLE `data_poli_ibu` (
  `id` int(255) NOT NULL,
  `namakk` varchar(30) NOT NULL,
  `nokartu` varchar(25) NOT NULL,
  `namaP` varchar(30) NOT NULL,
  `jeniskel` varchar(25) NOT NULL,
  `umur` varchar(25) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `jenisk` text NOT NULL,
  `tggl` date NOT NULL,
  `jam` time(6) NOT NULL,
  `namaib` text NOT NULL,
  `umurib` varchar(10) NOT NULL,
  `alamatib` text NOT NULL,
  `kerjib` text NOT NULL,
  `namas` text NOT NULL,
  `umurs` varchar(10) NOT NULL,
  `kerjs` text NOT NULL,
  `g` int(2) NOT NULL,
  `p` int(2) NOT NULL,
  `a` int(2) NOT NULL,
  `haid` date NOT NULL,
  `partus` date NOT NULL,
  `keluhan` varchar(128) NOT NULL,
  `tinggi` int(3) NOT NULL,
  `berat` int(3) NOT NULL,
  `lper` int(3) NOT NULL,
  `imt` decimal(10,2) NOT NULL,
  `suhu` decimal(10,2) NOT NULL,
  `sistole` int(4) NOT NULL,
  `distole` int(4) NOT NULL,
  `rrt` decimal(10,2) NOT NULL,
  `hrt` decimal(10,2) NOT NULL,
  `tdf` text NOT NULL,
  `butrs` text NOT NULL,
  `djk` decimal(10,2) NOT NULL,
  `letakj` text NOT NULL,
  `pdai` text NOT NULL,
  `gerj` text NOT NULL,
  `insp` text NOT NULL,
  `hb` decimal(10,2) NOT NULL,
  `uralbu` decimal(10,2) NOT NULL,
  `urredu` decimal(10,2) NOT NULL,
  `diagnosa` text NOT NULL,
  `pengo` varchar(256) NOT NULL,
  `kosnl` text NOT NULL,
  `rujuk` text NOT NULL,
  `tenagam` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `data_poli_ibu`
--

INSERT INTO `data_poli_ibu` (`id`, `namakk`, `nokartu`, `namaP`, `jeniskel`, `umur`, `alamat`, `jenisk`, `tggl`, `jam`, `namaib`, `umurib`, `alamatib`, `kerjib`, `namas`, `umurs`, `kerjs`, `g`, `p`, `a`, `haid`, `partus`, `keluhan`, `tinggi`, `berat`, `lper`, `imt`, `suhu`, `sistole`, `distole`, `rrt`, `hrt`, `tdf`, `butrs`, `djk`, `letakj`, `pdai`, `gerj`, `insp`, `hb`, `uralbu`, `urredu`, `diagnosa`, `pengo`, `kosnl`, `rujuk`, `tenagam`) VALUES
(7, 'selamat', '0985', 'andi', 'laki_laki', '13', 'Padang lua', 'Baru', '2020-11-16', '02:34:00.000000', 'andi', '13', 'Padang lua', 'qwqw', 'qwqw', '23', 'wewe', 0, 0, 0, '0000-00-00', '0000-00-00', '', 0, 0, 0, '0.00', '0.00', 0, 0, '0.00', '0.00', '--', '--', '0.00', '--', '--', '--', '--', '0.00', '0.00', '0.00', 'Diagnosa tidak di pilih', '', '', 'Tidak', 'Tenaga medis tidak di pilih');

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_poli_umum`
--

CREATE TABLE `data_poli_umum` (
  `id_pu` int(255) NOT NULL,
  `namakk` varchar(25) NOT NULL,
  `nokartu` varchar(25) NOT NULL,
  `namaP` varchar(50) NOT NULL,
  `jeniskel` varchar(25) NOT NULL,
  `umur` varchar(25) NOT NULL,
  `alamat` varchar(45) NOT NULL,
  `jenis_kunjungan` text NOT NULL,
  `tanggal_pu` date NOT NULL,
  `jam_pu` time(4) NOT NULL,
  `keluhan_pu` varchar(256) NOT NULL,
  `tinggi_pu` int(3) NOT NULL,
  `berat_pu` int(3) NOT NULL,
  `lebar_pu` int(3) NOT NULL,
  `imt_pu` decimal(10,2) NOT NULL,
  `suhu_pu` decimal(10,2) NOT NULL,
  `sistole_pu` int(4) NOT NULL,
  `distole_pu` int(4) NOT NULL,
  `rrt_pu` decimal(10,2) NOT NULL,
  `hrt_pu` decimal(10,2) NOT NULL,
  `hb_pu` decimal(10,2) NOT NULL,
  `gdarah_pu` decimal(10,2) NOT NULL,
  `pdarah_pu` decimal(10,2) NOT NULL,
  `diagnosa_pu` text NOT NULL,
  `pengobatan_pu` varchar(256) NOT NULL,
  `konsl_pu` varchar(256) NOT NULL,
  `rujuk_pu` text NOT NULL,
  `petugas_pu` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `data_poli_umum`
--

INSERT INTO `data_poli_umum` (`id_pu`, `namakk`, `nokartu`, `namaP`, `jeniskel`, `umur`, `alamat`, `jenis_kunjungan`, `tanggal_pu`, `jam_pu`, `keluhan_pu`, `tinggi_pu`, `berat_pu`, `lebar_pu`, `imt_pu`, `suhu_pu`, `sistole_pu`, `distole_pu`, `rrt_pu`, `hrt_pu`, `hb_pu`, `gdarah_pu`, `pdarah_pu`, `diagnosa_pu`, `pengobatan_pu`, `konsl_pu`, `rujuk_pu`, `petugas_pu`) VALUES
(26, 'n/a', 's0007_re', 'Patient146', 'n/a', '20', 'n/a', 'Baru', '2024-05-16', '09:45:00.0000', '', 0, 0, 0, '0.00', '0.00', 0, 21, '0.00', '0.00', '0.00', '0.00', '0.00', 'Penyakit Infeksi Usus\r\n', '', '', 'Ya', 'Dr.Susanti');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_diagnosa`
--

CREATE TABLE `tb_diagnosa` (
  `id` int(12) NOT NULL,
  `kode` varchar(8) NOT NULL,
  `jenis_penyakit` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_diagnosa`
--

INSERT INTO `tb_diagnosa` (`id`, `kode`, `jenis_penyakit`) VALUES
(1, 'A00-A09', 'Penyakit Infeksi Usus\r\n'),
(2, 'A00-A09', ' Kholera\r\n'),
(3, 'A01.0', 'Demam Tifoid'),
(6, 'A33', 'Tetanus');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_petugas`
--

CREATE TABLE `tb_petugas` (
  `id` int(5) NOT NULL,
  `nik` int(20) NOT NULL,
  `nama_petugas` text NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_petugas`
--

INSERT INTO `tb_petugas` (`id`, `nik`, `nama_petugas`, `status`) VALUES
(4, 1234, 'Dr.Cahyono', 'Aktif'),
(5, 9876, 'Dr.Susanti', 'Non Aktif');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `image` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_active` int(1) NOT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `image`, `password`, `role_id`, `is_active`, `date_created`) VALUES
(1, 'Admin Developer', 'admin@dev.com', 'default.jpg', '$2y$10$pZMdAjhlyrfU/rsdOV.YZ.bFHvYsOjOESRiwTKTqCrq1eckt3wYzG', 1, 1, 0),
(2, 'Agus Tian', 'agustian01@gmail.com', 'Cuplikan_layar_2023-09-18_081919.png', '$2y$10$ZuiSIgBTEsE3yL6U/ubRMe6OEpG1ma62tYFScdMbGzgb.Dh6i.G0W', 3, 1, 1595482971),
(5, 'Admin Puskesmas', 'admin@rstian.com', 'default.jpg', '$2y$10$q/76RdY2pkY5vHVyhsFzEOSx.NmYH0KVwJa.ELUrj/VoTfKoUDjqC', 2, 1, 1600092475),
(6, 'Petugas Puskesmas', 'petugas@rstian.com', 'default.jpg', '$2y$10$jp1Tz159Sfe7XRqUbczewuCvsl642axL/nluhFM9LYReXHtAAdC.e', 3, 1, 1600092740),
(7, 'Petugas 2 Puskesmas', 'petugas2@rstian.com', 'default.jpg', '$2y$10$NidmhiDm1m7nJqpt6yJvUe3T1PNZx3tMdiJMjAQhJ4CnC78rKJg2a', 3, 1, 1600092938),
(8, 'Tian Aja', 'tian@gmail.com', 'default.jpg', '$2y$10$ZuiSIgBTEsE3yL6U/ubRMe6OEpG1ma62tYFScdMbGzgb.Dh6i.G0W', 1, 1, 1600094586),
(10, 'Agustiawan', 'agustiawanibul10@gmail.com', 'default.jpg', '$2y$10$c4EogVKaX7TYroVydbJOt.pfscuaehOOdab.zkueVRFwy8kXZFBM6', 2, 1, 1714680224);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_access_menu`
--

CREATE TABLE `user_access_menu` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user_access_menu`
--

INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES
(1, 1, 1),
(2, 1, 4),
(3, 2, 4),
(4, 2, 7),
(5, 1, 2),
(6, 2, 3),
(7, 1, 7),
(9, 1, 10),
(10, 2, 10),
(11, 3, 3),
(12, 3, 4),
(13, 3, 7),
(14, 3, 10),
(15, 1, 3),
(16, 2, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_menu`
--

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL,
  `menu` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user_menu`
--

INSERT INTO `user_menu` (`id`, `menu`) VALUES
(1, 'Admin'),
(2, 'Menu'),
(3, 'Welcome'),
(4, 'User'),
(7, 'Entry'),
(10, 'RekamMedis');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_pasien`
--

CREATE TABLE `user_pasien` (
  `id` int(11) NOT NULL,
  `nama` varchar(10) DEFAULT NULL,
  `no_kartu` varchar(8) DEFAULT NULL,
  `umur` varchar(3) DEFAULT NULL,
  `j_kelamin` varchar(6) DEFAULT NULL,
  `nama_kk` varchar(22) DEFAULT NULL,
  `status` varchar(7) DEFAULT NULL,
  `no_hp` varchar(9) DEFAULT NULL,
  `alamat` varchar(123) DEFAULT NULL,
  `tgl_lahir` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `user_pasien`
--

INSERT INTO `user_pasien` (`id`, `nama`, `no_kartu`, `umur`, `j_kelamin`, `nama_kk`, `status`, `no_hp`, `alamat`, `tgl_lahir`) VALUES
(1, 'Patient1', 's0016lre', '81', 'Male', 'Myocardial infarction', 'No', '29-Sep-90', 'Heparin Isosorbit-Mononitrate ASA Diazepam', '1990-02-12'),
(2, 'Patient1', 's0010_re', '81', 'female', 'Myocardial infarction', 'no', '29-Sep-90', 'Heparin Isosorbit-Mononitrate ASA Diazepam', '0000-00-00'),
(3, 'Patient1', 's0014lre', '81', 'female', 'Myocardial infarction', 'no', '29-Sep-90', 'Heparin Isosorbit-Mononitrate ASA Diazepam', '0000-00-00'),
(4, 'Patient2', 's0015lre', '58', 'female', 'Myocardial infarction', 'yes', '08-Oct-90', 'Nitrate Heparin Ca-antagonist Atropin Ranitidin', '0000-00-00'),
(5, 'Patient3', 's0017lre', '63', 'Male', 'Myocardial infarction', 'Yes', '02-Oct-90', 'Furosemide', '1990-02-01'),
(6, 'Patient4', 's0020are', '69', 'male', 'Myocardial infarction', 'no', '19-Oct-90', 'Nitrate Heparin Ca-antagonist Ca-antagonist Captopril Digitoxin', '0000-00-00'),
(7, 'Patient4', 's0020bre', '69', 'male', 'Myocardial infarction', 'no', '19-Oct-90', 'Nitrate Heparin Ca-antagonist Ca-antagonist Captopril Digitoxin', '0000-00-00'),
(8, 'Patient5', 's0031lre', '74', 'male', 'Myocardial infarction', 'no', '23-Oct-90', 'ASA Ca-antagonist Amiloride+Chlorothiazide Triflupromazin Nitrate', '0000-00-00'),
(9, 'Patient5', 's0021are', '74', 'male', 'Myocardial infarction', 'no', '23-Oct-90', 'ASA Ca-antagonist Amiloride+Chlorothiazide Triflupromazin Nitrate', '0000-00-00'),
(10, 'Patient5', 's0025lre', '74', 'male', 'Myocardial infarction', 'no', '23-Oct-90', 'ASA Ca-antagonist Amiloride+Chlorothiazide Triflupromazin Nitrate', '0000-00-00'),
(11, 'Patient5', 's0021bre', '74', 'male', 'Myocardial infarction', 'no', '23-Oct-90', 'ASA Ca-antagonist Amiloride+Chlorothiazide Triflupromazin Nitrate', '0000-00-00'),
(12, 'Patient5', 's0101lre', '74', 'male', 'Myocardial infarction', 'no', '23-Oct-90', 'ASA Ca-antagonist Amiloride+Chlorothiazide Triflupromazin Nitrate', '0000-00-00'),
(13, 'Patient6', 's0027lre', '62', 'female', 'Myocardial infarction', 'yes', '19-Oct-90', 'Nitrate Heparin ASA L-Thyroxin', '0000-00-00'),
(14, 'Patient6', 's0064lre', '62', 'female', 'Myocardial infarction', 'yes', '19-Oct-90', 'Nitrate Heparin ASA L-Thyroxin', '0000-00-00'),
(15, 'Patient6', 's0022lre', '62', 'female', 'Myocardial infarction', 'yes', '19-Oct-90', 'Nitrate Heparin ASA L-Thyroxin', '0000-00-00'),
(16, 'Patient7', 's0026lre', '70', 'male', 'Myocardial infarction', 'no', '28-Oct-90', 'Isosorbit-Mononitrate ASA Ca-antagonist', '0000-00-00'),
(17, 'Patient7', 's0029lre', '70', 'male', 'Myocardial infarction', 'no', '28-Oct-90', 'Isosorbit-Mononitrate ASA Ca-antagonist', '0000-00-00'),
(18, 'Patient7', 's0078lre', '70', 'male', 'Myocardial infarction', 'no', '28-Oct-90', 'Isosorbit-Mononitrate ASA Ca-antagonist', '0000-00-00'),
(19, 'Patient7', 's0038lre', '70', 'male', 'Myocardial infarction', 'no', '28-Oct-90', 'Isosorbit-Mononitrate ASA Ca-antagonist', '0000-00-00'),
(20, 'Patient8', 's0068lre', '60', 'male', 'Myocardial infarction', 'yes', '25-Oct-90', 'Heparin ASA Isosorbit-Mononitrate Atropin Ranitidin', '0000-00-00'),
(21, 'Patient8', 's0028lre', '60', 'Female', 'Myocardial infarction', 'Yes', '25-Oct-90', 'Heparin ASA Isosorbit-Mononitrate Atropin Ranitidin', '2000-02-03'),
(22, 'Patient8', 's0037lre', '60', 'male', 'Myocardial infarction', 'yes', '25-Oct-90', 'Heparin ASA Isosorbit-Mononitrate Atropin Ranitidin', '0000-00-00'),
(23, 'Patient9', 's0035_re', '66', 'male', 'Myocardial infarction', 'yes', '26-Oct-90', 'Nitrate Heparin ASA', '0000-00-00'),
(24, 'Patient10', 's0061lre', '46', 'male', 'Myocardial infarction', 'no', '01-Nov-90', 'Heparin ASA Isosorbit-Dinitrate Molsidomin Metoprolol Amiloride+Chlorothiazide Ca-antagonist', '0000-00-00'),
(25, 'Patient10', 's0042lre', '46', 'male', 'Myocardial infarction', 'no', '01-Nov-90', 'Heparin ASA Isosorbit-Dinitrate Molsidomin Metoprolol Amiloride+Chlorothiazide Ca-antagonist', '0000-00-00'),
(26, 'Patient10', 's0036lre', '46', 'male', 'Myocardial infarction', 'no', '01-Nov-90', 'Heparin ASA Isosorbit-Dinitrate Molsidomin Metoprolol Amiloride+Chlorothiazide Ca-antagonist', '0000-00-00'),
(27, 'Patient11', 's0049lre', '62', 'female', 'Myocardial infarction', 'no', '06-Nov-90', 'Nitrate Triflupromazin Diazepam', '0000-00-00'),
(28, 'Patient11', 's0039lre', '62', 'female', 'Myocardial infarction', 'no', '06-Nov-90', 'Nitrate Triflupromazin Diazepam', '0000-00-00'),
(29, 'Patient11', 's0067lre', '62', 'female', 'Myocardial infarction', 'no', '06-Nov-90', 'Nitrate Triflupromazin Diazepam', '0000-00-00'),
(30, 'Patient11', 's0044lre', '62', 'female', 'Myocardial infarction', 'no', '06-Nov-90', 'Nitrate Triflupromazin Diazepam', '0000-00-00'),
(31, 'Patient12', 's0050lre', '67', 'male', 'Myocardial infarction', 'yes', '09-Nov-90', 'Heparin ASA Diazepam Isosorbit-Mononitrate Ranitidin', '0000-00-00'),
(32, 'Patient12', 's0043lre', '67', 'male', 'Myocardial infarction', 'yes', '09-Nov-90', 'Heparin ASA Diazepam Isosorbit-Mononitrate Ranitidin', '0000-00-00'),
(33, 'Patient13', 's0072lre', '71', 'female', 'Myocardial infarction', 'yes', '09-Nov-90', 'Heparin ASA Isosorbit-Mononitrate Insulin Triflupromazin', '0000-00-00'),
(34, 'Patient13', 's0045lre', '71', 'female', 'Myocardial infarction', 'yes', '09-Nov-90', 'Heparin ASA Isosorbit-Mononitrate Insulin Triflupromazin', '0000-00-00'),
(35, 'Patient13', 's0051lre', '71', 'female', 'Myocardial infarction', 'yes', '09-Nov-90', 'Heparin ASA Isosorbit-Mononitrate Insulin Triflupromazin', '0000-00-00'),
(36, 'Patient14', 's0071lre', '75', 'male', 'Myocardial infarction', 'no', '12-Nov-90', 'Heparin ASA Isosorbit-Mononitrate Ca-antagonist Ranitidin', '0000-00-00'),
(37, 'Patient14', 's0046lre', '75', 'male', 'Myocardial infarction', 'no', '12-Nov-90', 'Heparin ASA Isosorbit-Mononitrate Ca-antagonist Ranitidin', '0000-00-00'),
(38, 'Patient14', 's0056lre', '75', 'male', 'Myocardial infarction', 'no', '12-Nov-90', 'Heparin ASA Isosorbit-Mononitrate Ca-antagonist Ranitidin', '0000-00-00'),
(39, 'Patient15', 's0047lre', '68', 'female', 'Myocardial infarction', 'no', '12-Nov-90', 'Heparin ASA Furosemide Metoprolol Isosorbit-Mononitrate Ca-antagonist', '0000-00-00'),
(40, 'Patient15', 's0152lre', '68', 'female', 'Myocardial infarction', 'no', '12-Nov-90', 'Heparin ASA Furosemide Metoprolol Isosorbit-Mononitrate Ca-antagonist', '0000-00-00'),
(41, 'Patient15', 's0057lre', '68', 'female', 'Myocardial infarction', 'no', '12-Nov-90', 'Heparin ASA Furosemide Metoprolol Isosorbit-Mononitrate Ca-antagonist', '0000-00-00'),
(42, 'Patient16', 's0060lre', '63', 'male', 'Myocardial infarction', 'no', '13-Nov-90', 'Heparin Isosorbit-Mononitrate ASA Maalox', '0000-00-00'),
(43, 'Patient16', 's0076lre', '63', 'male', 'Myocardial infarction', 'no', '13-Nov-90', 'Heparin Isosorbit-Mononitrate ASA Maalox', '0000-00-00'),
(44, 'Patient16', 's0052lre', '63', 'male', 'Myocardial infarction', 'no', '13-Nov-90', 'Heparin Isosorbit-Mononitrate ASA Maalox', '0000-00-00'),
(45, 'Patient17', 's0053lre', '60', 'male', 'Myocardial infarction', 'no', '18-Nov-90', 'Nitrate Triflupromazin ASA Diazepam Oxazepam', '0000-00-00'),
(46, 'Patient17', 's0075lre', '60', 'male', 'Myocardial infarction', 'no', '18-Nov-90', 'Nitrate Triflupromazin ASA Diazepam Oxazepam', '0000-00-00'),
(47, 'Patient17', 's0055lre', '60', 'male', 'Myocardial infarction', 'no', '18-Nov-90', 'Nitrate Triflupromazin ASA Diazepam Oxazepam', '0000-00-00'),
(48, 'Patient17', 's0063lre', '60', 'male', 'Myocardial infarction', 'no', '18-Nov-90', 'Nitrate Triflupromazin ASA Diazepam Oxazepam', '0000-00-00'),
(49, 'Patient18', 's0059lre', '52', 'male', 'Myocardial infarction', 'no', '17-Nov-90', 'Nitrate Heparin ASA Ca-antagonist Atropin Triflupromazin', '0000-00-00'),
(50, 'Patient18', 's0054lre', '52', 'male', 'Myocardial infarction', 'no', '17-Nov-90', 'Nitrate Heparin ASA Ca-antagonist Atropin Triflupromazin', '0000-00-00'),
(51, 'Patient18', 's0082lre', '52', 'male', 'Myocardial infarction', 'no', '17-Nov-90', 'Nitrate Heparin ASA Ca-antagonist Atropin Triflupromazin', '0000-00-00'),
(52, 'Patient19', 's0058lre', '57', 'male', 'Myocardial infarction', 'yes', '24-Nov-90', 'Heparin Isosorbit-Mononitrate ASA Diazepam Ranitidin', '0000-00-00'),
(53, 'Patient19', 's0070lre', '57', 'male', 'Myocardial infarction', 'yes', '24-Nov-90', 'Heparin Isosorbit-Mononitrate ASA Diazepam Ranitidin', '0000-00-00'),
(54, 'Patient19', 's0077lre', '57', 'male', 'Myocardial infarction', 'yes', '24-Nov-90', 'Heparin Isosorbit-Mononitrate ASA Diazepam Ranitidin', '0000-00-00'),
(55, 'Patient20', 's0079lre', '54', 'female', 'Myocardial infarction', 'no', '26-Nov-90', 'Heparin ASA Ca-antagonist Isosorbit-Dinitrate Diazepam', '0000-00-00'),
(56, 'Patient20', 's0062lre', '54', 'female', 'Myocardial infarction', 'no', '26-Nov-90', 'Heparin ASA Ca-antagonist Isosorbit-Dinitrate Diazepam', '0000-00-00'),
(57, 'Patient20', 's0069lre', '54', 'female', 'Myocardial infarction', 'no', '26-Nov-90', 'Heparin ASA Ca-antagonist Isosorbit-Dinitrate Diazepam', '0000-00-00'),
(58, 'Patient21', 's0097lre', '67', 'male', 'Myocardial infarction', 'yes', '29-Nov-90', 'Heparin ASA Isosorbit-Mononitrate Diazepam Theophyllin', '0000-00-00'),
(59, 'Patient21', 's0073lre', '67', 'male', 'Myocardial infarction', 'yes', '29-Nov-90', 'Heparin ASA Isosorbit-Mononitrate Diazepam Theophyllin', '0000-00-00'),
(60, 'Patient21', 's0065lre', '67', 'male', 'Myocardial infarction', 'yes', '29-Nov-90', 'Heparin ASA Isosorbit-Mononitrate Diazepam Theophyllin', '0000-00-00'),
(61, 'Patient22', 's0149lre', '43', 'male', 'Myocardial infarction', 'yes', '29-Nov-90', 'Heparin ASA Isosorbit-Mononitrate Atropin Diazepam', '0000-00-00'),
(62, 'Patient22', 's0066lre', '43', 'male', 'Myocardial infarction', 'yes', '29-Nov-90', 'Heparin ASA Isosorbit-Mononitrate Atropin Diazepam', '0000-00-00'),
(63, 'Patient22', 's0074lre', '43', 'male', 'Myocardial infarction', 'yes', '29-Nov-90', 'Heparin ASA Isosorbit-Mononitrate Atropin Diazepam', '0000-00-00'),
(64, 'Patient23', 's0103lre', '69', 'male', 'Myocardial infarction', 'no', '17-Dec-90', 'ASA Isosorbit-Dinitrate Molsidomin Triflupromazin', '0000-00-00'),
(65, 'Patient23', 's0080lre', '69', 'male', 'Myocardial infarction', 'no', '17-Dec-90', 'ASA Isosorbit-Dinitrate Molsidomin Triflupromazin', '0000-00-00'),
(66, 'Patient23', 's0085lre', '69', 'male', 'Myocardial infarction', 'no', '17-Dec-90', 'ASA Isosorbit-Dinitrate Molsidomin Triflupromazin', '0000-00-00'),
(67, 'Patient23', 's0081lre', '69', 'male', 'Myocardial infarction', 'no', '17-Dec-90', 'ASA Isosorbit-Dinitrate Molsidomin Triflupromazin', '0000-00-00'),
(68, 'Patient24', 's0083lre', '52', 'male', 'Myocardial infarction', 'no', '20-Dec-90', 'Metoprolol Isosorbit-Dinitrate ASA', '0000-00-00'),
(69, 'Patient24', 's0086lre', '52', 'male', 'Myocardial infarction', 'no', '20-Dec-90', 'Metoprolol Isosorbit-Dinitrate ASA', '0000-00-00'),
(70, 'Patient24', 's0084lre', '52', 'male', 'Myocardial infarction', 'no', '20-Dec-90', 'Metoprolol Isosorbit-Dinitrate ASA', '0000-00-00'),
(71, 'Patient24', 's0094lre', '52', 'male', 'Myocardial infarction', 'no', '20-Dec-90', 'Metoprolol Isosorbit-Dinitrate ASA', '0000-00-00'),
(72, 'Patient25', 's0150lre', '76', 'male', 'Myocardial infarction', 'no', '30-Dec-90', 'Heparin ASA Isosorbit-Mononitrate Digitoxin', '0000-00-00'),
(73, 'Patient25', 's0087lre', '76', 'male', 'Myocardial infarction', 'no', '30-Dec-90', 'Heparin ASA Isosorbit-Mononitrate Digitoxin', '0000-00-00'),
(74, 'Patient25', 's0091lre', '76', 'male', 'Myocardial infarction', 'no', '30-Dec-90', 'Heparin ASA Isosorbit-Mononitrate Digitoxin', '0000-00-00'),
(75, 'Patient26', 's0095lre', '74', 'female', 'Myocardial infarction', 'no', '30-Dec-90', 'Heparin ASA Isosorbit-Mononitrate', '0000-00-00'),
(76, 'Patient26', 's0088lre', '74', 'female', 'Myocardial infarction', 'no', '30-Dec-90', 'Heparin ASA Isosorbit-Mononitrate', '0000-00-00'),
(77, 'Patient27', 's0151lre', '53', 'male', 'Myocardial infarction', 'no', '01-Jan-91', 'Heparin ASA Isosorbit-Dinitrate Metoprolol', '0000-00-00'),
(78, 'Patient27', 's0089lre', '53', 'male', 'Myocardial infarction', 'no', '01-Jan-91', 'Heparin ASA Isosorbit-Dinitrate Metoprolol', '0000-00-00'),
(79, 'Patient27', 's0096lre', '53', 'male', 'Myocardial infarction', 'no', '01-Jan-91', 'Heparin ASA Isosorbit-Dinitrate Metoprolol', '0000-00-00'),
(80, 'Patient28', 's0090lre', '49', 'male', 'Myocardial infarction', 'yes', '30-Dec-90', 'Heparin ASA Ca-antagonist Isosorbit-Dinitrate Atropin', '0000-00-00'),
(81, 'Patient28', 's0093lre', '49', 'male', 'Myocardial infarction', 'yes', '30-Dec-90', 'Heparin ASA Ca-antagonist Isosorbit-Dinitrate Atropin', '0000-00-00'),
(82, 'Patient28', 's0108lre', '49', 'male', 'Myocardial infarction', 'yes', '30-Dec-90', 'Heparin ASA Ca-antagonist Isosorbit-Dinitrate Atropin', '0000-00-00'),
(83, 'Patient29', 's0098lre', '49', 'male', 'Myocardial infarction', 'yes', '05-Jan-91', 'Heparin ASA Isosorbit-Mononitrate Colfarit', '0000-00-00'),
(84, 'Patient29', 's0122lre', '49', 'male', 'Myocardial infarction', 'yes', '05-Jan-91', 'Heparin ASA Isosorbit-Mononitrate Colfarit', '0000-00-00'),
(85, 'Patient29', 's0092lre', '49', 'male', 'Myocardial infarction', 'yes', '05-Jan-91', 'Heparin ASA Isosorbit-Mononitrate Colfarit', '0000-00-00'),
(86, 'Patient30', 's0117lre', '63', 'male', 'Myocardial infarction', 'yes', '15-Jan-91', 'Heparin Isosorbit-Mononitrate Furosemide Metoprolol', '0000-00-00'),
(87, 'Patient30', 's0099lre', '63', 'male', 'Myocardial infarction', 'yes', '15-Jan-91', 'Heparin Isosorbit-Mononitrate Furosemide Metoprolol', '0000-00-00'),
(88, 'Patient30', 's0107lre', '63', 'male', 'Myocardial infarction', 'yes', '15-Jan-91', 'Heparin Isosorbit-Mononitrate Furosemide Metoprolol', '0000-00-00'),
(89, 'Patient30', 's0153lre', '63', 'male', 'Myocardial infarction', 'yes', '15-Jan-91', 'Heparin Isosorbit-Mononitrate Furosemide Metoprolol', '0000-00-00'),
(90, 'Patient31', 's0114lre', '65', 'male', 'Myocardial infarction', 'yes', '15-Jan-91', 'Heparin ASA Ca-antagonist Oxazepam Metoprolol Paracetamol Isosorbit-Dinitrate', '0000-00-00'),
(91, 'Patient31', 's0100lre', '65', 'male', 'Myocardial infarction', 'yes', '15-Jan-91', 'Heparin ASA Ca-antagonist Oxazepam Metoprolol Paracetamol Isosorbit-Dinitrate', '0000-00-00'),
(92, 'Patient31', 's0127lre', '65', 'male', 'Myocardial infarction', 'yes', '15-Jan-91', 'Heparin ASA Ca-antagonist Oxazepam Metoprolol Paracetamol Isosorbit-Dinitrate', '0000-00-00'),
(93, 'Patient31', 's0104lre', '65', 'male', 'Myocardial infarction', 'yes', '15-Jan-91', 'Heparin ASA Ca-antagonist Oxazepam Metoprolol Paracetamol Isosorbit-Dinitrate', '0000-00-00'),
(94, 'Patient32', 's0165lre', '49', 'male', 'Myocardial infarction', 'no', '17-Jan-91', 'Nitrate Heparin ASA Metoprolol Ca-antagonist Paracetamol Cefalexin', '0000-00-00'),
(95, 'Patient32', 's0115lre', '49', 'male', 'Myocardial infarction', 'no', '17-Jan-91', 'Nitrate Heparin ASA Metoprolol Ca-antagonist Paracetamol Cefalexin', '0000-00-00'),
(96, 'Patient32', 's0102lre', '49', 'male', 'Myocardial infarction', 'no', '17-Jan-91', 'Nitrate Heparin ASA Metoprolol Ca-antagonist Paracetamol Cefalexin', '0000-00-00'),
(97, 'Patient32', 's0106lre', '49', 'male', 'Myocardial infarction', 'no', '17-Jan-91', 'Nitrate Heparin ASA Metoprolol Ca-antagonist Paracetamol Cefalexin', '0000-00-00'),
(98, 'Patient33', 's0121lre', '60', 'male', 'Myocardial infarction', 'no', '20-Jan-91', 'Nitrate Heparin Triflupromazin', '0000-00-00'),
(99, 'Patient33', 's0113lre', '60', 'male', 'Myocardial infarction', 'no', '20-Jan-91', 'Nitrate Heparin Triflupromazin', '0000-00-00'),
(100, 'Patient33', 's0105lre', '60', 'male', 'Myocardial infarction', 'no', '20-Jan-91', 'Nitrate Heparin Triflupromazin', '0000-00-00'),
(101, 'Patient33', 's0157lre', '60', 'male', 'Myocardial infarction', 'no', '20-Jan-91', 'Nitrate Heparin Triflupromazin', '0000-00-00'),
(102, 'Patient34', 's0109lre', '49', 'male', 'Myocardial infarction', 'yes', '22-Jan-91', 'n/a', '0000-00-00'),
(103, 'Patient34', 's0118lre', '49', 'male', 'Myocardial infarction', 'yes', '22-Jan-91', 'n/a', '0000-00-00'),
(104, 'Patient34', 's0158lre', '49', 'male', 'Myocardial infarction', 'yes', '22-Jan-91', 'n/a', '0000-00-00'),
(105, 'Patient34', 's0123lre', '49', 'male', 'Myocardial infarction', 'yes', '22-Jan-91', 'n/a', '0000-00-00'),
(106, 'Patient35', 's0110lre', '40', 'male', 'Myocardial infarction', 'no', '23-Jan-91', 'Isosorbit-Dinitrate ASA Ca-antagonist Molsidomin Oxazepam', '0000-00-00'),
(107, 'Patient35', 's0145lre', '40', 'male', 'Myocardial infarction', 'no', '23-Jan-91', 'Isosorbit-Dinitrate ASA Ca-antagonist Molsidomin Oxazepam', '0000-00-00'),
(108, 'Patient35', 's0124lre', '40', 'male', 'Myocardial infarction', 'no', '23-Jan-91', 'Isosorbit-Dinitrate ASA Ca-antagonist Molsidomin Oxazepam', '0000-00-00'),
(109, 'Patient35', 's0119lre', '40', 'male', 'Myocardial infarction', 'no', '23-Jan-91', 'Isosorbit-Dinitrate ASA Ca-antagonist Molsidomin Oxazepam', '0000-00-00'),
(110, 'Patient36', 's0111lre', '75', 'male', 'Myocardial infarction', 'no', '23-Jan-91', 'Heparin ASA Isosorbit-Mononitrate', '0000-00-00'),
(111, 'Patient36', 's0126lre', '75', 'male', 'Myocardial infarction', 'no', '23-Jan-91', 'Heparin ASA Isosorbit-Mononitrate', '0000-00-00'),
(112, 'Patient36', 's0116lre', '75', 'male', 'Myocardial infarction', 'no', '23-Jan-91', 'Heparin ASA Isosorbit-Mononitrate', '0000-00-00'),
(113, 'Patient37', 's0112lre', '50', 'male', 'Myocardial infarction', 'yes', '21-Jan-91', 'Heparin ASA Isosorbit-Dinitrate Atropin', '0000-00-00'),
(114, 'Patient37', 's0120lre', '50', 'male', 'Myocardial infarction', 'yes', '21-Jan-91', 'Heparin ASA Isosorbit-Dinitrate Atropin', '0000-00-00'),
(115, 'Patient38', 's0125lre', '36', 'male', 'Myocardial infarction', 'yes', '02-Feb-91', 'Nitrate Heparin ASA Oxazepam', '0000-00-00'),
(116, 'Patient38', 's0128lre', '36', 'male', 'Myocardial infarction', 'yes', '02-Feb-91', 'Nitrate Heparin ASA Oxazepam', '0000-00-00'),
(117, 'Patient38', 's0162lre', '36', 'male', 'Myocardial infarction', 'yes', '02-Feb-91', 'Nitrate Heparin ASA Oxazepam', '0000-00-00'),
(118, 'Patient39', 's0164lre', '61', 'male', 'Myocardial infarction', 'yes', '13-Feb-91', 'Nitrate Heparin ASA Metprolol Molsidomin Ranitidin Oxazepam', '0000-00-00'),
(119, 'Patient39', 's0134lre', '61', 'male', 'Myocardial infarction', 'yes', '13-Feb-91', 'Nitrate Heparin ASA Metprolol Molsidomin Ranitidin Oxazepam', '0000-00-00'),
(120, 'Patient39', 's0129lre', '61', 'male', 'Myocardial infarction', 'yes', '13-Feb-91', 'Nitrate Heparin ASA Metprolol Molsidomin Ranitidin Oxazepam', '0000-00-00'),
(121, 'Patient40', 's0131lre', '51', 'male', 'Myocardial infarction', 'yes', '15-Feb-91', 'ASA Isosorbit-Dinitrate Ca-antagonist', '0000-00-00'),
(122, 'Patient40', 's0133lre', '51', 'male', 'Myocardial infarction', 'yes', '15-Feb-91', 'ASA Isosorbit-Dinitrate Ca-antagonist', '0000-00-00'),
(123, 'Patient40', 's0219lre', '51', 'male', 'Myocardial infarction', 'yes', '15-Feb-91', 'ASA Isosorbit-Dinitrate Ca-antagonist', '0000-00-00'),
(124, 'Patient40', 's0130lre', '51', 'male', 'Myocardial infarction', 'yes', '15-Feb-91', 'ASA Isosorbit-Dinitrate Ca-antagonist', '0000-00-00'),
(125, 'Patient41', 's0276lre', '65', 'male', 'Myocardial infarction', 'no', '24-Feb-91', 'Nitrate Heparin ASA', '0000-00-00'),
(126, 'Patient41', 's0136lre', '65', 'male', 'Myocardial infarction', 'no', '24-Feb-91', 'Nitrate Heparin ASA', '0000-00-00'),
(127, 'Patient41', 's0138lre', '65', 'male', 'Myocardial infarction', 'no', '24-Feb-91', 'Nitrate Heparin ASA', '0000-00-00'),
(128, 'Patient41', 's0132lre', '65', 'male', 'Myocardial infarction', 'no', '24-Feb-91', 'Nitrate Heparin ASA', '0000-00-00'),
(129, 'Patient42', 's0135lre', '49', 'male', 'Myocardial infarction', 'yes', '26-Feb-91', 'ASA Ca-antagonist Isosorbit-Dinitrate Molsidomin Metoprolol', '0000-00-00'),
(130, 'Patient42', 's0347lre', '49', 'male', 'Myocardial infarction', 'yes', '26-Feb-91', 'ASA Ca-antagonist Isosorbit-Dinitrate Molsidomin Metoprolol', '0000-00-00'),
(131, 'Patient42', 's0140lre', '49', 'male', 'Myocardial infarction', 'yes', '26-Feb-91', 'ASA Ca-antagonist Isosorbit-Dinitrate Molsidomin Metoprolol', '0000-00-00'),
(132, 'Patient42', 's0137lre', '49', 'male', 'Myocardial infarction', 'yes', '26-Feb-91', 'ASA Ca-antagonist Isosorbit-Dinitrate Molsidomin Metoprolol', '0000-00-00'),
(133, 'Patient43', 's0278lre', '52', 'female', 'Myocardial infarction', 'yes', '08-Mar-91', 'Isosorbit-Mononitrate ASA Metoprolol', '0000-00-00'),
(134, 'Patient43', 's0141lre', '52', 'female', 'Myocardial infarction', 'yes', '08-Mar-91', 'Isosorbit-Mononitrate ASA Metoprolol', '0000-00-00'),
(135, 'Patient43', 's0144lre', '52', 'female', 'Myocardial infarction', 'yes', '08-Mar-91', 'Isosorbit-Mononitrate ASA Metoprolol', '0000-00-00'),
(136, 'Patient44', 's0159lre', '66', 'female', 'Myocardial infarction', 'yes', '14-Mar-91', 'Nitrate Heparin ASA Metoprolol Phenprocoumon', '0000-00-00'),
(137, 'Patient44', 's0142lre', '66', 'female', 'Myocardial infarction', 'yes', '14-Mar-91', 'Nitrate Heparin ASA Metoprolol Phenprocoumon', '0000-00-00'),
(138, 'Patient44', 's0146lre', '66', 'female', 'Myocardial infarction', 'yes', '14-Mar-91', 'Nitrate Heparin ASA Metoprolol Phenprocoumon', '0000-00-00'),
(139, 'Patient44', 's0143lre', '66', 'female', 'Myocardial infarction', 'yes', '14-Mar-91', 'Nitrate Heparin ASA Metoprolol Phenprocoumon', '0000-00-00'),
(140, 'Patient45', 's0148lre', '44', 'male', 'Myocardial infarction', 'no', '03-Apr-91', 'ASA Ca-antagonist Isosorbit-Mononitrate', '0000-00-00'),
(141, 'Patient45', 's0155lre', '44', 'male', 'Myocardial infarction', 'no', '03-Apr-91', 'ASA Ca-antagonist Isosorbit-Mononitrate', '0000-00-00'),
(142, 'Patient45', 's0147lre', '44', 'male', 'Myocardial infarction', 'no', '03-Apr-91', 'ASA Ca-antagonist Isosorbit-Mononitrate', '0000-00-00'),
(143, 'Patient45', 's0217lre', '44', 'male', 'Myocardial infarction', 'no', '03-Apr-91', 'ASA Ca-antagonist Isosorbit-Mononitrate', '0000-00-00'),
(144, 'Patient46', 's0156lre', '64', 'female', 'Myocardial infarction', 'yes', '17-Apr-91', 'Heparin Isosorbit-Mononitrate ASA Digitoxin Captopril Amiloride+Chlorothiazide L-Thyrox', '0000-00-00'),
(145, 'Patient46', 's0168lre', '64', 'female', 'Myocardial infarction', 'yes', '17-Apr-91', 'Heparin Isosorbit-Mononitrate ASA Digitoxin Captopril Amiloride+Chlorothiazide L-Thyrox', '0000-00-00'),
(146, 'Patient46', 's0184lre', '64', 'female', 'Myocardial infarction', 'yes', '17-Apr-91', 'Heparin Isosorbit-Mononitrate ASA Digitoxin Captopril Amiloride+Chlorothiazide L-Thyrox', '0000-00-00'),
(147, 'Patient46', 's0161lre', '64', 'female', 'Myocardial infarction', 'yes', '17-Apr-91', 'Heparin Isosorbit-Mononitrate ASA Digitoxin Captopril Amiloride+Chlorothiazide L-Thyrox', '0000-00-00'),
(148, 'Patient47', 's0160lre', '86', 'male', 'Myocardial infarction', 'yes', '18-Apr-91', 'Heparin ASA Digitoxin Isosorbit-Mononitrate Ca-antagonist Furosemide', '0000-00-00'),
(149, 'Patient47', 's0167lre', '86', 'male', 'Myocardial infarction', 'yes', '18-Apr-91', 'Heparin ASA Digitoxin Isosorbit-Mononitrate Ca-antagonist Furosemide', '0000-00-00'),
(150, 'Patient47', 's0163lre', '86', 'male', 'Myocardial infarction', 'yes', '18-Apr-91', 'Heparin ASA Digitoxin Isosorbit-Mononitrate Ca-antagonist Furosemide', '0000-00-00'),
(151, 'Patient48', 's0172lre', '64', 'male', 'Myocardial infarction', 'no', '07-May-91', 'Nitrate Heparin', '0000-00-00'),
(152, 'Patient48', 's0180lre', '64', 'male', 'Myocardial infarction', 'no', '07-May-91', 'Nitrate Heparin', '0000-00-00'),
(153, 'Patient48', 's0277lre', '64', 'male', 'Myocardial infarction', 'no', '07-May-91', 'Nitrate Heparin', '0000-00-00'),
(154, 'Patient48', 's0171lre', '64', 'male', 'Myocardial infarction', 'no', '07-May-91', 'Nitrate Heparin', '0000-00-00'),
(155, 'Patient49', 's0178lre', '42', 'female', 'Myocardial infarction', 'yes', '13-May-91', 'Nitrate Atropin ASA', '0000-00-00'),
(156, 'Patient49', 's0314lre', '42', 'female', 'Myocardial infarction', 'yes', '13-May-91', 'Nitrate Atropin ASA', '0000-00-00'),
(157, 'Patient49', 's0186lre', '42', 'female', 'Myocardial infarction', 'yes', '13-May-91', 'Nitrate Atropin ASA', '0000-00-00'),
(158, 'Patient49', 's0173lre', '42', 'female', 'Myocardial infarction', 'yes', '13-May-91', 'Nitrate Atropin ASA', '0000-00-00'),
(159, 'Patient50', 's0177lre', '44', 'female', 'Myocardial infarction', 'yes', '12-May-91', 'ASA Metoprolol Isosorbit-Mononitrate Triflupromazin', '0000-00-00'),
(160, 'Patient50', 's0174lre', '44', 'female', 'Myocardial infarction', 'yes', '12-May-91', 'ASA Metoprolol Isosorbit-Mononitrate Triflupromazin', '0000-00-00'),
(161, 'Patient50', 's0185lre', '44', 'female', 'Myocardial infarction', 'yes', '12-May-91', 'ASA Metoprolol Isosorbit-Mononitrate Triflupromazin', '0000-00-00'),
(162, 'Patient50', 's0215lre', '44', 'female', 'Myocardial infarction', 'yes', '12-May-91', 'ASA Metoprolol Isosorbit-Mononitrate Triflupromazin', '0000-00-00'),
(163, 'Patient51', 's0179lre', '55', 'female', 'Myocardial infarction', 'no', '17-May-91', 'Nitrate Heparin Atropin Triflupromazin ASA', '0000-00-00'),
(164, 'Patient51', 's0181lre', '55', 'female', 'Myocardial infarction', 'no', '17-May-91', 'Nitrate Heparin Atropin Triflupromazin ASA', '0000-00-00'),
(165, 'Patient51', 's0187lre', '55', 'female', 'Myocardial infarction', 'no', '17-May-91', 'Nitrate Heparin Atropin Triflupromazin ASA', '0000-00-00'),
(166, 'Patient51', 's0213lre', '55', 'female', 'Myocardial infarction', 'no', '17-May-91', 'Nitrate Heparin Atropin Triflupromazin ASA', '0000-00-00'),
(167, 'Patient52', 's0190lre', '44', 'male', 'Myocardial infarction', 'yes', '14-May-91', 'Nitrate Heparin Metoprolol ASA', '0000-00-00'),
(168, 'Patient53', 's0191lre', '66', 'male', 'Myocardial infarction', 'yes', '03-Jun-91', 'Nitrate Heparin Metoprolol ASA', '0000-00-00'),
(169, 'Patient54', 's0218lre', '47', 'male', 'Myocardial infarction', 'no', '10-Jun-91', 'Nitrate Triflupromazin ASA Heparin Furosemide Atropin', '0000-00-00'),
(170, 'Patient54', 's0195lre', '47', 'male', 'Myocardial infarction', 'no', '10-Jun-91', 'Nitrate Triflupromazin ASA Heparin Furosemide Atropin', '0000-00-00'),
(171, 'Patient54', 's0197lre', '47', 'male', 'Myocardial infarction', 'no', '10-Jun-91', 'Nitrate Triflupromazin ASA Heparin Furosemide Atropin', '0000-00-00'),
(172, 'Patient54', 's0192lre', '47', 'male', 'Myocardial infarction', 'no', '10-Jun-91', 'Nitrate Triflupromazin ASA Heparin Furosemide Atropin', '0000-00-00'),
(173, 'Patient55', 's0194lre', '66', 'female', 'Myocardial infarction', 'no', '31-May-91', 'Heparin ASA Metoprolol Isosorbit-Mononitrate Ca-antagonist Atropin', '0000-00-00'),
(174, 'Patient56', 's0196lre', '48', 'female', 'Myocardial infarction', 'no', '15-Jun-91', 'Nitrate Heparin ASA Metoprolol Ranitidin', '0000-00-00'),
(175, 'Patient57', 's0198lre', '53', 'male', 'Myocardial infarction', 'yes', '30-Jun-91', 'Nitrate Heparin ASA Metoprolol', '0000-00-00'),
(176, 'Patient58', 's0216lre', '52', 'female', 'Myocardial infarction', 'yes', '11-Jul-91', 'Nitrate Heparin ASA L-Thyroxin Omeprazol Atropin', '0000-00-00'),
(177, 'Patient59', 's0208lre', '63', 'female', 'Myocardial infarction', 'no', '31-Jul-91', 'Heparin ASA Isosorbit-Dinitrate Molsidomin Furosemide', '0000-00-00'),
(178, 'Patient60', 's0209lre', '54', 'male', 'Myocardial infarction', 'no', '10-Aug-91', 'Nitrate Heparin ASA Metoprolol', '0000-00-00'),
(179, 'Patient61', 's0210lre', '37', 'male', 'Myocardial infarction', 'yes', '15-Aug-91', 'Heparin ASA Metoprolol Isosorbit-Mononitrate', '0000-00-00'),
(180, 'Patient62', 's0212lre', '68', 'female', 'Myocardial infarction', 'no', '24-Aug-91', 'Heparin ASA Isosorbit-Dinitrate Amiloride+Chlorothiazide Ca-antagonist Metoprolol Furosemide', '0000-00-00'),
(181, 'Patient63', 's0214lre', '62', 'male', 'Myocardial infarction', 'yes', '23-Aug-91', 'Nitrate Heparin ASA Metoprolol Digitoxin', '0000-00-00'),
(182, 'Patient64', 's0220lre', '72', 'male', 'Myocardial infarction', 'no', '30-Aug-91', 'Nitrate Heparin ASA Amiloride+Chlorothiazide Omeprazol', '0000-00-00'),
(183, 'Patient65', 's0221lre', '52', 'male', 'Myocardial infarction', 'no', '13-Sep-91', 'ASA Metoprolol Isosorbit-Mononitrate Molsidomin', '0000-00-00'),
(184, 'Patient65', 's0229lre', '52', 'male', 'Myocardial infarction', 'no', '13-Sep-91', 'ASA Metoprolol Isosorbit-Mononitrate Molsidomin', '0000-00-00'),
(185, 'Patient65', 's0282lre', '52', 'male', 'Myocardial infarction', 'no', '13-Sep-91', 'ASA Metoprolol Isosorbit-Mononitrate Molsidomin', '0000-00-00'),
(186, 'Patient65', 's0226lre', '52', 'male', 'Myocardial infarction', 'no', '13-Sep-91', 'ASA Metoprolol Isosorbit-Mononitrate Molsidomin', '0000-00-00'),
(187, 'Patient66', 's0280lre', '68', 'male', 'Myocardial infarction', 'no', '17-Sep-91', 'Heparin ASA Isosorbit-Mononitrate Atropin', '0000-00-00'),
(188, 'Patient66', 's0231lre', '68', 'male', 'Myocardial infarction', 'no', '17-Sep-91', 'Heparin ASA Isosorbit-Mononitrate Atropin', '0000-00-00'),
(189, 'Patient66', 's0225lre', '68', 'male', 'Myocardial infarction', 'no', '17-Sep-91', 'Heparin ASA Isosorbit-Mononitrate Atropin', '0000-00-00'),
(190, 'Patient67', 's0227lre', '59', 'male', 'Myocardial infarction', 'yes', '17-Sep-91', 'Nitrate Heparin ASA Metoprolol', '0000-00-00'),
(191, 'Patient67', 's0230lre', '59', 'male', 'Myocardial infarction', 'yes', '17-Sep-91', 'Nitrate Heparin ASA Metoprolol', '0000-00-00'),
(192, 'Patient67', 's0283lre', '59', 'male', 'Myocardial infarction', 'yes', '17-Sep-91', 'Nitrate Heparin ASA Metoprolol', '0000-00-00'),
(193, 'Patient68', 's0228lre', '44', 'male', 'Myocardial infarction', 'yes', '11-Sep-91', 'Heparin ASA Isosorbit-Mononitrate Ca-antagonist L-Thyroxin', '0000-00-00'),
(194, 'Patient69', 's0233lre', '62', 'male', 'Myocardial infarction', 'yes', '18-Nov-91', 'Nitrate ASA Diazepam', '0000-00-00'),
(195, 'Patient69', 's0232lre', '62', 'male', 'Myocardial infarction', 'yes', '18-Nov-91', 'Nitrate ASA Diazepam', '0000-00-00'),
(196, 'Patient69', 's0284lre', '62', 'male', 'Myocardial infarction', 'yes', '18-Nov-91', 'Nitrate ASA Diazepam', '0000-00-00'),
(197, 'Patient69', 's0234lre', '62', 'male', 'Myocardial infarction', 'yes', '18-Nov-91', 'Nitrate ASA Diazepam', '0000-00-00'),
(198, 'Patient70', 's0235lre', '52', 'male', 'Myocardial infarction', 'yes', '18-Nov-91', 'Nitrate ASA Magnesium', '0000-00-00'),
(199, 'Patient71', 's0236lre', '80', 'male', 'Myocardial infarction', 'yes', '29-Nov-91', 'Nitrate Heparin ASA Ca-antagonist', '0000-00-00'),
(200, 'Patient72', 's0240lre', '40', 'male', 'Myocardial infarction', 'yes', '16-Jan-92', 'Magnesium Metprolol ASA Diazepam', '0000-00-00'),
(201, 'Patient72', 's0237lre', '40', 'male', 'Myocardial infarction', 'yes', '16-Jan-92', 'Magnesium Metprolol ASA Diazepam', '0000-00-00'),
(202, 'Patient72', 's0244lre', '40', 'male', 'Myocardial infarction', 'yes', '16-Jan-92', 'Magnesium Metprolol ASA Diazepam', '0000-00-00'),
(203, 'Patient72', 's0318lre', '40', 'male', 'Myocardial infarction', 'yes', '16-Jan-92', 'Magnesium Metprolol ASA Diazepam', '0000-00-00'),
(204, 'Patient73', 's0249lre', '63', 'male', 'Myocardial infarction', 'no', '16-Jan-92', 'Nitrate Heparin ASA Metprolol Metoprolol Diazepam Atropin', '0000-00-00'),
(205, 'Patient73', 's0252lre', '63', 'male', 'Myocardial infarction', 'no', '16-Jan-92', 'Nitrate Heparin ASA Metprolol Metoprolol Diazepam Atropin', '0000-00-00'),
(206, 'Patient73', 's0238lre', '63', 'male', 'Myocardial infarction', 'no', '16-Jan-92', 'Nitrate Heparin ASA Metprolol Metoprolol Diazepam Atropin', '0000-00-00'),
(207, 'Patient73', 's0243lre', '63', 'male', 'Myocardial infarction', 'no', '16-Jan-92', 'Nitrate Heparin ASA Metprolol Metoprolol Diazepam Atropin', '0000-00-00'),
(208, 'Patient74', 's0245lre', '80', 'female', 'Myocardial infarction', 'no', '16-Jan-92', 'Nitrate Heparin ASA Digitoxin Amiloride+Chlorothiazide', '0000-00-00'),
(209, 'Patient74', 's0406lre', '80', 'female', 'Myocardial infarction', 'no', '16-Jan-92', 'Nitrate Heparin ASA Digitoxin Amiloride+Chlorothiazide', '0000-00-00'),
(210, 'Patient74', 's0241lre', '80', 'female', 'Myocardial infarction', 'no', '16-Jan-92', 'Nitrate Heparin ASA Digitoxin Amiloride+Chlorothiazide', '0000-00-00'),
(211, 'Patient74', 's0239lre', '80', 'female', 'Myocardial infarction', 'no', '16-Jan-92', 'Nitrate Heparin ASA Digitoxin Amiloride+Chlorothiazide', '0000-00-00'),
(212, 'Patient75', 's0248lre', '50', 'male', 'Myocardial infarction', 'yes', '20-Jan-92', 'Nitrate Magnesium ASA Diazepam', '0000-00-00'),
(213, 'Patient75', 's0246lre', '50', 'male', 'Myocardial infarction', 'yes', '20-Jan-92', 'Nitrate Magnesium ASA Diazepam', '0000-00-00'),
(214, 'Patient75', 's0242lre', '50', 'male', 'Myocardial infarction', 'yes', '20-Jan-92', 'Nitrate Magnesium ASA Diazepam', '0000-00-00'),
(215, 'Patient75', 's0327lre', '50', 'male', 'Myocardial infarction', 'yes', '20-Jan-92', 'Nitrate Magnesium ASA Diazepam', '0000-00-00'),
(216, 'Patient76', 's0247lre', '43', 'male', 'Myocardial infarction', 'yes', '30-Jan-92', 'Nitrate Metoprolol Furosemide', '0000-00-00'),
(217, 'Patient76', 's0319lre', '43', 'male', 'Myocardial infarction', 'yes', '30-Jan-92', 'Nitrate Metoprolol Furosemide', '0000-00-00'),
(218, 'Patient76', 's0250lre', '43', 'male', 'Myocardial infarction', 'yes', '30-Jan-92', 'Nitrate Metoprolol Furosemide', '0000-00-00'),
(219, 'Patient76', 's0253lre', '43', 'male', 'Myocardial infarction', 'yes', '30-Jan-92', 'Nitrate Metoprolol Furosemide', '0000-00-00'),
(220, 'Patient77', 's0251lre', '65', 'male', 'Myocardial infarction', 'yes', '12-Feb-92', 'Nitrate Heparin ASA Digoxin Glibenclamide', '0000-00-00'),
(221, 'Patient77', 's0285lre', '65', 'male', 'Myocardial infarction', 'yes', '12-Feb-92', 'Nitrate Heparin ASA Digoxin Glibenclamide', '0000-00-00'),
(222, 'Patient77', 's0258lre', '65', 'male', 'Myocardial infarction', 'yes', '12-Feb-92', 'Nitrate Heparin ASA Digoxin Glibenclamide', '0000-00-00'),
(223, 'Patient77', 's0254lre', '65', 'male', 'Myocardial infarction', 'yes', '12-Feb-92', 'Nitrate Heparin ASA Digoxin Glibenclamide', '0000-00-00'),
(224, 'Patient78', 's0255lre', '68', 'male', 'Myocardial infarction', 'yes', '19-Feb-92', 'Nitrate Heparin ASA Furosemide Atropin Diazepam', '0000-00-00'),
(225, 'Patient78', 's0317lre', '68', 'male', 'Myocardial infarction', 'yes', '19-Feb-92', 'Nitrate Heparin ASA Furosemide Atropin Diazepam', '0000-00-00'),
(226, 'Patient78', 's0259lre', '68', 'male', 'Myocardial infarction', 'yes', '19-Feb-92', 'Nitrate Heparin ASA Furosemide Atropin Diazepam', '0000-00-00'),
(227, 'Patient78', 's0262lre', '68', 'male', 'Myocardial infarction', 'yes', '19-Feb-92', 'Nitrate Heparin ASA Furosemide Atropin Diazepam', '0000-00-00'),
(228, 'Patient79', 's0256lre', '75', 'male', 'Myocardial infarction', 'yes', '18-Feb-92', 'Heparin ASA Isosorbit-Dinitrate Furosemide Glibenclamide Ambroxol', '0000-00-00'),
(229, 'Patient79', 's0263lre', '75', 'male', 'Myocardial infarction', 'yes', '18-Feb-92', 'Heparin ASA Isosorbit-Dinitrate Furosemide Glibenclamide Ambroxol', '0000-00-00'),
(230, 'Patient79', 's0269lre', '75', 'male', 'Myocardial infarction', 'yes', '18-Feb-92', 'Heparin ASA Isosorbit-Dinitrate Furosemide Glibenclamide Ambroxol', '0000-00-00'),
(231, 'Patient79', 's0257lre', '75', 'male', 'Myocardial infarction', 'yes', '18-Feb-92', 'Heparin ASA Isosorbit-Dinitrate Furosemide Glibenclamide Ambroxol', '0000-00-00'),
(232, 'Patient80', 's0260lre', '48', 'male', 'Myocardial infarction', 'yes', '24-Feb-92', 'Nitrate Heparin ASA Furosemide Magnesium Atropin', '0000-00-00'),
(233, 'Patient80', 's0315lre', '48', 'male', 'Myocardial infarction', 'yes', '24-Feb-92', 'Nitrate Heparin ASA Furosemide Magnesium Atropin', '0000-00-00'),
(234, 'Patient80', 's0261lre', '48', 'male', 'Myocardial infarction', 'yes', '24-Feb-92', 'Nitrate Heparin ASA Furosemide Magnesium Atropin', '0000-00-00'),
(235, 'Patient80', 's0265lre', '48', 'male', 'Myocardial infarction', 'yes', '24-Feb-92', 'Nitrate Heparin ASA Furosemide Magnesium Atropin', '0000-00-00'),
(236, 'Patient81', 's0264lre', '53', 'male', 'Myocardial infarction', 'yes', '04-Mar-92', 'Nitrate Ca-antagonist Amiloride+Chlorothiazide ASA', '0000-00-00'),
(237, 'Patient81', 's0346lre', '53', 'male', 'Myocardial infarction', 'yes', '04-Mar-92', 'Nitrate Ca-antagonist Amiloride+Chlorothiazide ASA', '0000-00-00'),
(238, 'Patient81', 's0270lre', '53', 'male', 'Myocardial infarction', 'yes', '04-Mar-92', 'Nitrate Ca-antagonist Amiloride+Chlorothiazide ASA', '0000-00-00'),
(239, 'Patient81', 's0266lre', '53', 'male', 'Myocardial infarction', 'yes', '04-Mar-92', 'Nitrate Ca-antagonist Amiloride+Chlorothiazide ASA', '0000-00-00'),
(240, 'Patient82', 's0320lre', '65', 'male', 'Myocardial infarction', 'no', '16-Mar-92', 'Nitrate Heparin Cephalosporin Metoprolol Furosemide ASA Ranitidin Diazepam', '0000-00-00'),
(241, 'Patient82', 's0267lre', '65', 'male', 'Myocardial infarction', 'no', '16-Mar-92', 'Nitrate Heparin Cephalosporin Metoprolol Furosemide ASA Ranitidin Diazepam', '0000-00-00'),
(242, 'Patient82', 's0271lre', '65', 'male', 'Myocardial infarction', 'no', '16-Mar-92', 'Nitrate Heparin Cephalosporin Metoprolol Furosemide ASA Ranitidin Diazepam', '0000-00-00'),
(243, 'Patient82', 's0279lre', '65', 'male', 'Myocardial infarction', 'no', '16-Mar-92', 'Nitrate Heparin Cephalosporin Metoprolol Furosemide ASA Ranitidin Diazepam', '0000-00-00'),
(244, 'Patient83', 's0286lre', '45', 'male', 'Myocardial infarction', 'yes', '15-Mar-92', 'Nitrate Magnesium Ca-antagonist Metoprolol', '0000-00-00'),
(245, 'Patient83', 's0272lre', '45', 'male', 'Myocardial infarction', 'yes', '15-Mar-92', 'Nitrate Magnesium Ca-antagonist Metoprolol', '0000-00-00'),
(246, 'Patient83', 's0290lre', '45', 'male', 'Myocardial infarction', 'yes', '15-Mar-92', 'Nitrate Magnesium Ca-antagonist Metoprolol', '0000-00-00'),
(247, 'Patient83', 's0268lre', '45', 'male', 'Myocardial infarction', 'yes', '15-Mar-92', 'Nitrate Magnesium Ca-antagonist Metoprolol', '0000-00-00'),
(248, 'Patient84', 's0288lre', '55', 'male', 'Myocardial infarction', 'yes', '24-Mar-92', 'Nitrate ASA Captopril', '0000-00-00'),
(249, 'Patient84', 's0281lre', '55', 'male', 'Myocardial infarction', 'yes', '24-Mar-92', 'Nitrate ASA Captopril', '0000-00-00'),
(250, 'Patient84', 's0289lre', '55', 'male', 'Myocardial infarction', 'yes', '24-Mar-92', 'Nitrate ASA Captopril', '0000-00-00'),
(251, 'Patient84', 's0313lre', '55', 'male', 'Myocardial infarction', 'yes', '24-Mar-92', 'Nitrate ASA Captopril', '0000-00-00'),
(252, 'Patient85', 's0297lre', '56', 'female', 'Myocardial infarction', 'yes', '04-Jun-92', 'ASA Magnesium Glibenclamide Isosorbit-Dinitrate', '0000-00-00'),
(253, 'Patient85', 's0298lre', '56', 'female', 'Myocardial infarction', 'yes', '04-Jun-92', 'ASA Magnesium Glibenclamide Isosorbit-Dinitrate', '0000-00-00'),
(254, 'Patient85', 's0296lre', '56', 'female', 'Myocardial infarction', 'yes', '04-Jun-92', 'ASA Magnesium Glibenclamide Isosorbit-Dinitrate', '0000-00-00'),
(255, 'Patient85', 's0345lre', '56', 'female', 'Myocardial infarction', 'yes', '04-Jun-92', 'ASA Magnesium Glibenclamide Isosorbit-Dinitrate', '0000-00-00'),
(256, 'Patient86', 's0316lre', '66', 'female', 'Myocardial infarction', 'yes', '31-Jul-92', 'Heparin Isosorbit-Dinitrate ret. Molsidomin Digoxin Ca-antagonist Furosemide Captopril ASA Glibenclamide Ranitidin Diazepam', '0000-00-00'),
(257, 'Patient87', 's0321lre', '66', 'male', 'Myocardial infarction', 'yes', '11-Aug-92', 'Nitrate Heparin ASA Ranitidin', '0000-00-00'),
(258, 'Patient87', 's0326lre', '66', 'male', 'Myocardial infarction', 'yes', '11-Aug-92', 'Nitrate Heparin ASA Ranitidin', '0000-00-00'),
(259, 'Patient87', 's0330lre', '66', 'male', 'Myocardial infarction', 'yes', '11-Aug-92', 'Nitrate Heparin ASA Ranitidin', '0000-00-00'),
(260, 'Patient88', 's0352lre', '54', 'male', 'Myocardial infarction', 'yes', '22-Oct-92', 'Nitrate ASA Metoprolol', '0000-00-00'),
(261, 'Patient88', 's0413lre', '54', 'male', 'Myocardial infarction', 'yes', '22-Oct-92', 'Nitrate ASA Metoprolol', '0000-00-00'),
(262, 'Patient88', 's0339lre', '54', 'male', 'Myocardial infarction', 'yes', '22-Oct-92', 'Nitrate ASA Metoprolol', '0000-00-00'),
(263, 'Patient88', 's0343lre', '54', 'male', 'Myocardial infarction', 'yes', '22-Oct-92', 'Nitrate ASA Metoprolol', '0000-00-00'),
(264, 'Patient89', 's0355lre', '80', 'female', 'Myocardial infarction', 'no', '25-Oct-92', 'Nitrate Heparin', '0000-00-00'),
(265, 'Patient89', 's0344lre', '80', 'female', 'Myocardial infarction', 'no', '25-Oct-92', 'Nitrate Heparin', '0000-00-00'),
(266, 'Patient89', 's0372lre', '80', 'female', 'Myocardial infarction', 'no', '25-Oct-92', 'Nitrate Heparin', '0000-00-00'),
(267, 'Patient89', 's0359lre', '80', 'female', 'Myocardial infarction', 'no', '25-Oct-92', 'Nitrate Heparin', '0000-00-00'),
(268, 'Patient90', 's0356lre', '51', 'male', 'Myocardial infarction', 'yes', '26-Oct-92', 'Heparin ASA Isosorbit-Dinitrate Molsidomin', '0000-00-00'),
(269, 'Patient90', 's0360lre', '51', 'male', 'Myocardial infarction', 'yes', '26-Oct-92', 'Heparin ASA Isosorbit-Dinitrate Molsidomin', '0000-00-00'),
(270, 'Patient90', 's0418lre', '51', 'male', 'Myocardial infarction', 'yes', '26-Oct-92', 'Heparin ASA Isosorbit-Dinitrate Molsidomin', '0000-00-00'),
(271, 'Patient90', 's0348lre', '51', 'male', 'Myocardial infarction', 'yes', '26-Oct-92', 'Heparin ASA Isosorbit-Dinitrate Molsidomin', '0000-00-00'),
(272, 'Patient91', 's0353lre', '78', 'female', 'Myocardial infarction', 'no', '29-Oct-92', 'Nitrate Heparin ASA Metoprolol', '0000-00-00'),
(273, 'Patient91', 's0408lre', '78', 'female', 'Myocardial infarction', 'no', '29-Oct-92', 'Nitrate Heparin ASA Metoprolol', '0000-00-00'),
(274, 'Patient91', 's0357lre', '78', 'female', 'Myocardial infarction', 'no', '29-Oct-92', 'Nitrate Heparin ASA Metoprolol', '0000-00-00'),
(275, 'Patient91', 's0361lre', '78', 'female', 'Myocardial infarction', 'no', '29-Oct-92', 'Nitrate Heparin ASA Metoprolol', '0000-00-00'),
(276, 'Patient92', 's0354lre', '44', 'female', 'Myocardial infarction', 'yes', '28-Oct-92', 'Nitrate Heparin ASA Ca-antagonist Atropin', '0000-00-00'),
(277, 'Patient92', 's0411lre', '44', 'female', 'Myocardial infarction', 'yes', '28-Oct-92', 'Nitrate Heparin ASA Ca-antagonist Atropin', '0000-00-00'),
(278, 'Patient92', 's0358lre', '44', 'female', 'Myocardial infarction', 'yes', '28-Oct-92', 'Nitrate Heparin ASA Ca-antagonist Atropin', '0000-00-00'),
(279, 'Patient92', 's0362lre', '44', 'female', 'Myocardial infarction', 'yes', '28-Oct-92', 'Nitrate Heparin ASA Ca-antagonist Atropin', '0000-00-00'),
(280, 'Patient93', 's0367lre', '48', 'male', 'Myocardial infarction', 'yes', '18-Nov-92', 'Heparin ASA Metoprolol Isosorbit-Dinitrate', '0000-00-00'),
(281, 'Patient93', 's0371lre', '48', 'male', 'Myocardial infarction', 'yes', '18-Nov-92', 'Heparin ASA Metoprolol Isosorbit-Dinitrate', '0000-00-00'),
(282, 'Patient93', 's0378lre', '48', 'male', 'Myocardial infarction', 'yes', '18-Nov-92', 'Heparin ASA Metoprolol Isosorbit-Dinitrate', '0000-00-00'),
(283, 'Patient93', 's0396lre', '48', 'male', 'Myocardial infarction', 'yes', '18-Nov-92', 'Heparin ASA Metoprolol Isosorbit-Dinitrate', '0000-00-00'),
(284, 'Patient93', 's0375lre', '48', 'male', 'Myocardial infarction', 'yes', '18-Nov-92', 'Heparin ASA Metoprolol Isosorbit-Dinitrate', '0000-00-00'),
(285, 'Patient94', 's0412lre', '71', 'female', 'Myocardial infarction', 'no', '19-Nov-92', 'Nitrate Heparin ASA Digitoxin Furosemide', '0000-00-00'),
(286, 'Patient94', 's0370lre', '71', 'female', 'Myocardial infarction', 'no', '19-Nov-92', 'Nitrate Heparin ASA Digitoxin Furosemide', '0000-00-00'),
(287, 'Patient94', 's0368lre', '71', 'female', 'Myocardial infarction', 'no', '19-Nov-92', 'Nitrate Heparin ASA Digitoxin Furosemide', '0000-00-00'),
(288, 'Patient94', 's0376lre', '71', 'female', 'Myocardial infarction', 'no', '19-Nov-92', 'Nitrate Heparin ASA Digitoxin Furosemide', '0000-00-00'),
(289, 'Patient95', 's0369lre', '46', 'male', 'Myocardial infarction', 'yes', '19-Nov-92', 'Nitrate Heparin ASA Atropin', '0000-00-00'),
(290, 'Patient95', 's0373lre', '46', 'male', 'Myocardial infarction', 'yes', '19-Nov-92', 'Nitrate Heparin ASA Atropin', '0000-00-00'),
(291, 'Patient95', 's0417lre', '46', 'male', 'Myocardial infarction', 'yes', '19-Nov-92', 'Nitrate Heparin ASA Atropin', '0000-00-00'),
(292, 'Patient95', 's0377lre', '46', 'male', 'Myocardial infarction', 'yes', '19-Nov-92', 'Nitrate Heparin ASA Atropin', '0000-00-00'),
(293, 'Patient96', 's0379lre', '43', 'male', 'Myocardial infarction', 'yes', '02-Dec-92', 'Nitrate ASA Metoprolol Glibenclamide', '0000-00-00'),
(294, 'Patient96', 's0385lre', '43', 'male', 'Myocardial infarction', 'yes', '02-Dec-92', 'Nitrate ASA Metoprolol Glibenclamide', '0000-00-00'),
(295, 'Patient96', 's0381lre', '43', 'male', 'Myocardial infarction', 'yes', '02-Dec-92', 'Nitrate ASA Metoprolol Glibenclamide', '0000-00-00'),
(296, 'Patient96', 's0395lre', '43', 'male', 'Myocardial infarction', 'yes', '02-Dec-92', 'Nitrate ASA Metoprolol Glibenclamide', '0000-00-00'),
(297, 'Patient97', 's0380lre', '68', 'male', 'Myocardial infarction', 'no', '04-Dec-92', 'Heparin Digitoxin Furosemide ASA Ca-antagonist Isosorbit-Dinitrate Molsidomin', '0000-00-00'),
(298, 'Patient97', 's0384lre', '68', 'male', 'Myocardial infarction', 'no', '04-Dec-92', 'Heparin Digitoxin Furosemide ASA Ca-antagonist Isosorbit-Dinitrate Molsidomin', '0000-00-00'),
(299, 'Patient97', 's0394lre', '68', 'male', 'Myocardial infarction', 'no', '04-Dec-92', 'Heparin Digitoxin Furosemide ASA Ca-antagonist Isosorbit-Dinitrate Molsidomin', '0000-00-00'),
(300, 'Patient97', 's0382lre', '68', 'male', 'Myocardial infarction', 'no', '04-Dec-92', 'Heparin Digitoxin Furosemide ASA Ca-antagonist Isosorbit-Dinitrate Molsidomin', '0000-00-00'),
(301, 'Patient98', 's0409lre', '63', 'female', 'Myocardial infarction', 'no', '16-Dec-92', 'Heparin ASA Ca-antagonist Metoprolol Colestyramin Fibrate Isosorbit-Dinitrate Molsidomin', '0000-00-00'),
(302, 'Patient98', 's0386lre', '63', 'female', 'Myocardial infarction', 'no', '16-Dec-92', 'Heparin ASA Ca-antagonist Metoprolol Colestyramin Fibrate Isosorbit-Dinitrate Molsidomin', '0000-00-00'),
(303, 'Patient98', 's0398lre', '63', 'female', 'Myocardial infarction', 'no', '16-Dec-92', 'Heparin ASA Ca-antagonist Metoprolol Colestyramin Fibrate Isosorbit-Dinitrate Molsidomin', '0000-00-00'),
(304, 'Patient98', 's0389lre', '63', 'female', 'Myocardial infarction', 'no', '16-Dec-92', 'Heparin ASA Ca-antagonist Metoprolol Colestyramin Fibrate Isosorbit-Dinitrate Molsidomin', '0000-00-00'),
(305, 'Patient99', 's0388lre', '52', 'male', 'Myocardial infarction', 'yes', '17-Dec-92', 'Nitrate ASA Furosemide Lovastatin Triflupromazin', '0000-00-00'),
(306, 'Patient99', 's0419lre', '52', 'male', 'Myocardial infarction', 'yes', '17-Dec-92', 'Nitrate ASA Furosemide Lovastatin Triflupromazin', '0000-00-00'),
(307, 'Patient99', 's0387lre', '52', 'male', 'Myocardial infarction', 'yes', '17-Dec-92', 'Nitrate ASA Furosemide Lovastatin Triflupromazin', '0000-00-00'),
(308, 'Patient99', 's0397lre', '52', 'male', 'Myocardial infarction', 'yes', '17-Dec-92', 'Nitrate ASA Furosemide Lovastatin Triflupromazin', '0000-00-00'),
(309, 'Patient100', 's0399lre', '72', 'female', 'Myocardial infarction', 'no', '08-Jan-93', 'Heparin ASA Digoxin Furosemide Verapamil Enalapril Molsidomin Isosorbit-Dinitrate Glibenclamide Diazepam', '0000-00-00'),
(310, 'Patient100', 's0401lre', '72', 'female', 'Myocardial infarction', 'no', '08-Jan-93', 'Heparin ASA Digoxin Furosemide Verapamil Enalapril Molsidomin Isosorbit-Dinitrate Glibenclamide Diazepam', '0000-00-00'),
(311, 'Patient100', 's0407lre', '72', 'female', 'Myocardial infarction', 'no', '08-Jan-93', 'Heparin ASA Digoxin Furosemide Verapamil Enalapril Molsidomin Isosorbit-Dinitrate Glibenclamide Diazepam', '0000-00-00'),
(312, 'Patient101', 's0410lre', '57', 'male', 'Myocardial infarction', 'yes', '11-Jan-93', 'Nitrate Heparin Isosorbit-Dinitrate Molsidomin Furosemide Metoprolol Captopril Digitoxin Ca-antagonist', '0000-00-00'),
(313, 'Patient101', 's0400lre', '57', 'male', 'Myocardial infarction', 'yes', '11-Jan-93', 'Nitrate Heparin Isosorbit-Dinitrate Molsidomin Furosemide Metoprolol Captopril Digitoxin Ca-antagonist', '0000-00-00'),
(314, 'Patient101', 's0414lre', '57', 'male', 'Myocardial infarction', 'yes', '11-Jan-93', 'Nitrate Heparin Isosorbit-Dinitrate Molsidomin Furosemide Metoprolol Captopril Digitoxin Ca-antagonist', '0000-00-00'),
(315, 'Patient102', 's0416lre', '72', 'female', 'Myocardial infarction', 'no', '15-Mar-93', 'Heparin ASA Isosorbit-Dinitrate Furosemide Molsidomin', '0000-00-00'),
(316, 'Patient103', 's0332lre', '52', 'male', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(317, 'Patient104', 's0306lre', '58', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(318, 'Patient105', 's0303lre', '32', 'female', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(319, 'Patient106', 's0030_re', '46', 'male', 'Valvular heart disease', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(320, 'Patient107', 's0199_re', '41', 'female', 'Valvular heart disease', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(321, 'Patient108', 's0013_re', '77', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(322, 'Patient109', 's0349lre', '17', 'male', 'Dysrhythmia', 'no', 'n/a', 'n/a', '0000-00-00'),
(323, 'Patient110', 's0003_re', 'n/a', 'n/a', 'Valvular heart disease', 'no', 'n/a', 'n/a', '0000-00-00'),
(324, 'Patient111', 's0203_re', '75', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(325, 'Patient112', 's0169_re', '59', 'male', 'Dysrhythmia', 'no', 'n/a', 'n/a', '0000-00-00'),
(326, 'Patient113', 's0018cre', '65', 'female', 'Dysrhythmia', 'no', 'n/a', 'n/a', '0000-00-00'),
(327, 'Patient113', 's0018lre', '65', 'female', 'Dysrhythmia', 'no', 'n/a', 'n/a', '0000-00-00'),
(328, 'Patient114', 's0012_re', '68', 'female', 'Valvular heart disease', 'no', 'n/a', 'n/a', '0000-00-00'),
(329, 'Patient115', 's0023_re', '74', 'female', 'Heart failure (NYHA 2)', 'no', 'n/a', 'n/a', '0000-00-00'),
(330, 'Patient116', 's0302lre', '54', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(331, 'Patient117', 's0292lre', '37', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00');
INSERT INTO `user_pasien` (`id`, `nama`, `no_kartu`, `umur`, `j_kelamin`, `nama_kk`, `status`, `no_hp`, `alamat`, `tgl_lahir`) VALUES
(332, 'Patient117', 's0291lre', '37', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(333, 'Patient118', 's0183_re', '70', 'male', 'Heart failure (NYHA 3)', 'yes', 'n/a', 'n/a', '0000-00-00'),
(334, 'Patient119', 's0001_re', '83', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(335, 'Patient120', 's0331lre', '72', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(336, 'Patient121', 's0311lre', '69', 'female', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(337, 'Patient122', 's0312lre', '68', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(338, 'Patient123', 's0224_re', '61', 'female', 'Heart failure (NYHA 4)', 'no', 'n/a', 'n/a', '0000-00-00'),
(339, 'Patient125', 's0006_re', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(340, 'Patient126', 's0154_re', '62', 'male', 'Palpitation', 'no', 'n/a', 'n/a', '0000-00-00'),
(341, 'Patient127', 's0342lre', '32', 'female', 'Cardiomyopathy', 'no', 'n/a', 'n/a', '0000-00-00'),
(342, 'Patient127', 's0383lre', '32', 'female', 'Cardiomyopathy', 'no', 'n/a', 'n/a', '0000-00-00'),
(343, 'Patient128', 's0182_re', '63', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(344, 'Patient129', 's0189_re', '53', 'male', 'Cardiomyopathy', 'yes', 'n/a', 'n/a', '0000-00-00'),
(345, 'Patient130', 's0166_re', '75', 'male', 'Stable angina', 'no', 'n/a', 'n/a', '0000-00-00'),
(346, 'Patient131', 's0273lre', '26', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(347, 'Patient133', 's0393lre', '31', 'male', 'Dysrhythmia', 'yes', 'n/a', 'n/a', '0000-00-00'),
(348, 'Patient135', 's0334lre', '54', 'female', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(349, 'Patient136', 's0205_re', '51', 'male', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(350, 'Patient137', 's0392lre', '52', 'male', 'Cardiomyopathy', 'yes', 'n/a', 'n/a', '0000-00-00'),
(351, 'Patient138', 's0005_re', '84', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(352, 'Patient139', 's0223_re', '85', 'female', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(353, 'Patient140', 's0019_re', '75', 'female', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(354, 'Patient141', 's0307lre', '46', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(355, 'Patient142', 's0351lre', '54', 'male', 'Myocardial infarction', 'yes', 'n/a', 'n/a', '0000-00-00'),
(356, 'Patient143', 's0333lre', '67', 'male', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(357, 'Patient144', 's0341lre', '57', 'female', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(358, 'Patient145', 's0201_re', '63', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(359, 'Patient146', 's0007_re', '20', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(360, 'Patient147', 's0211_re', '81', 'male', 'Dysrhythmia', 'yes', 'n/a', 'n/a', '0000-00-00'),
(361, 'Patient148', 's0335lre', '58', 'male', 'Myocardial infarction', 'yes', 'n/a', 'n/a', '0000-00-00'),
(362, 'Patient149', 's0202are', '53', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(363, 'Patient149', 's0202bre', '53', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(364, 'Patient150', 's0287lre', '36', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(365, 'Patient151', 's0206_re', '66', 'female', 'Dysrhythmia', 'no', 'n/a', 'n/a', '0000-00-00'),
(366, 'Patient152', 's0004_re', '79', 'female', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(367, 'Patient153', 's0391lre', '52', 'male', 'Dysrhythmia', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(368, 'Patient154', 's0170_re', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(369, 'Patient155', 's0301lre', '37', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(370, 'Patient156', 's0299lre', '17', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(371, 'Patient157', 's0338lre', '87', 'male', 'Dysrhythmia', 'yes', 'n/a', 'n/a', '0000-00-00'),
(372, 'Patient158', 's0294lre', '64', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(373, 'Patient158', 's0295lre', '64', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(374, 'Patient159', 's0390lre', '73', 'male', 'Hypertrophy', 'yes', 'n/a', 'n/a', '0000-00-00'),
(375, 'Patient160', 's0222_re', '55', 'male', 'Myocardial infarction', 'yes', 'n/a', 'n/a', '0000-00-00'),
(376, 'Patient162', 's0193_re', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(377, 'Patient163', 's0034_re', '68', 'female', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(378, 'Patient164', 's0024bre', '87', 'female', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(379, 'Patient164', 's0024are', '87', 'female', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(380, 'Patient165', 's0322lre', '26', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(381, 'Patient165', 's0323lre', '26', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(382, 'Patient166', 's0275lre', 'n/a', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(383, 'Patient167', 's0200_re', '80', 'female', 'Cardiomyopathy', 'no', 'n/a', 'n/a', '0000-00-00'),
(384, 'Patient168', 's0033_re', '75', 'female', 'Dysrhythmia', 'no', 'n/a', 'n/a', '0000-00-00'),
(385, 'Patient168', 's0032_re', '75', 'female', 'Dysrhythmia', 'no', 'n/a', 'n/a', '0000-00-00'),
(386, 'Patient169', 's0328lre', '54', 'female', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(387, 'Patient169', 's0329lre', '54', 'female', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(388, 'Patient170', 's0274lre', 'n/a', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(389, 'Patient171', 's0364lre', '64', 'female', 'Bundle branch block', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(390, 'Patient172', 's0304lre', '50', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(391, 'Patient173', 's0305lre', '57', 'female', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(392, 'Patient174', 's0300lre', '26', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(393, 'Patient174', 's0324lre', '26', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(394, 'Patient174', 's0325lre', '26', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(395, 'Patient175', 's0009_re', '57', 'female', 'Bundle branch block', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(396, 'Patient176', 's0188_re', '79', 'female', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(397, 'Patient177', 's0366lre', '35', 'female', 'Dysrhythmia', 'no', 'n/a', 'n/a', '0000-00-00'),
(398, 'Patient178', 's0011_re', '85', 'female', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(399, 'Patient179', 's0176_re', '77', 'female', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(400, 'Patient180', 's0477_re', '37', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(401, 'Patient180', 's0490_re', '37', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(402, 'Patient180', 's0476_re', '37', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(403, 'Patient180', 's0545_re', '37', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(404, 'Patient180', 's0561_re', '37', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(405, 'Patient180', 's0374lre', '37', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(406, 'Patient180', 's0475_re', '37', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(407, 'Patient181', 's0204bre', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(408, 'Patient181', 's0204are', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(409, 'Patient182', 's0308lre', '29', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(410, 'Patient183', 's0175_re', '57', 'female', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(411, 'Patient184', 's0363lre', '81', 'female', 'Healthy control', 'no', 'n/a', 'n/a', '0000-00-00'),
(412, 'Patient185', 's0336lre', '22', 'female', 'Healthy control', 'no', 'n/a', 'n/a', '0000-00-00'),
(413, 'Patient186', 's0293lre', '45', 'male', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(414, 'Patient187', 's0207_re', '62', 'male', 'Dysrhythmia', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(415, 'Patient188', 's0365lre', '51', 'male', 'Valvular heart disease', 'no', 'n/a', 'n/a', '0000-00-00'),
(416, 'Patient189', 's0309lre', '61', 'male', 'Myocardial infarction', 'yes', 'n/a', 'n/a', '0000-00-00'),
(417, 'Patient190', 's0041_re', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(418, 'Patient190', 's0040_re', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(419, 'Patient191', 's0340lre', '60', 'male', 'Stable angina', 'yes', 'n/a', 'n/a', '0000-00-00'),
(420, 'Patient192', 's0048_re', '63', 'female', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(421, 'Patient193', 's0008_re', '59', 'female', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(422, 'Patient194', 's0310lre', '67', 'male', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(423, 'Patient195', 's0337lre', '71', 'female', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(424, 'Patient196', 's0002_re', '84', 'female', 'Unstable angina', 'no', 'n/a', 'n/a', '0000-00-00'),
(425, 'Patient197', 's0403lre', '51', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(426, 'Patient197', 's0350lre', '51', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(427, 'Patient198', 's0415lre', 'n/a', 'female', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(428, 'Patient198', 's0402lre', 'n/a', 'female', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(429, 'Patient199', 's0404lre', 'n/a', 'male', 'Bundle branch block', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(430, 'Patient200', 's0405lre', 'n/a', 'male', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(431, 'Patient201', 's0420_re', '39', 'male', 'Cardiomyopathy', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(432, 'Patient201', 's0423_re', '39', 'male', 'Cardiomyopathy', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(433, 'Patient202', 's0422_re', '29', 'male', 'Bundle branch block', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(434, 'Patient202', 's0421_re', '29', 'male', 'Bundle branch block', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(435, 'Patient203', 's0424_re', '32', 'male', 'Bundle branch block', 'no', 'n/a', 'n/a', '0000-00-00'),
(436, 'Patient204', 's0425_re', '67', 'male', 'Bundle branch block', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(437, 'Patient205', 's0426_re', '63', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(438, 'Patient206', 's0427_re', '32', 'male', 'Bundle branch block', 'no', 'n/a', 'n/a', '0000-00-00'),
(439, 'Patient207', 's0428_re', '46', 'male', 'Myocardial infarction', 'yes', 'n/a', 'n/a', '0000-00-00'),
(440, 'Patient208', 's0429_re', '46', 'male', 'Bundle branch block', 'no', 'n/a', 'n/a', '0000-00-00'),
(441, 'Patient208', 's0430_re', '46', 'male', 'Bundle branch block', 'no', 'n/a', 'n/a', '0000-00-00'),
(442, 'Patient209', 's0431_re', '51', 'male', 'Bundle branch block', 'yes', 'n/a', 'n/a', '0000-00-00'),
(443, 'Patient210', 's0432_re', '56', 'male', 'Hypertrophy', 'no', 'n/a', 'n/a', '0000-00-00'),
(444, 'Patient211', 's0433_re', '68', 'male', 'Myocardial infarction', 'yes', 'n/a', 'n/a', '0000-00-00'),
(445, 'Patient212', 's0434_re', '66', 'male', 'Hypertrophy', 'no', 'n/a', 'n/a', '0000-00-00'),
(446, 'Patient213', 's0435_re', '58', 'male', 'Bundle branch block', 'no', 'n/a', 'n/a', '0000-00-00'),
(447, 'Patient214', 's0436_re', '35', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(448, 'Patient215', 's0437_re', '82', 'male', 'Cardiomyopathy', 'no', 'n/a', 'n/a', '0000-00-00'),
(449, 'Patient216', 's0438_re', '73', 'female', 'Hypertrophy', 'no', 'n/a', 'n/a', '0000-00-00'),
(450, 'Patient217', 's0439_re', '62', 'female', 'Bundle branch block', 'no', 'n/a', 'n/a', '0000-00-00'),
(451, 'Patient218', 's0440_re', '70', 'male', 'Dysrhythmia', 'no', 'n/a', 'n/a', '0000-00-00'),
(452, 'Patient219', 's0441_re', '66', 'male', 'Bundle branch block', 'no', 'n/a', 'n/a', '0000-00-00'),
(453, 'Patient220', 's0442_re', '76', 'male', 'Bundle branch block', 'no', 'n/a', 'n/a', '0000-00-00'),
(454, 'Patient221', 's0443_re', '63', 'male', 'Hypertrophy', 'no', 'n/a', 'n/a', '0000-00-00'),
(455, 'Patient222', 's0444_re', '60', 'female', 'Cardiomyopathy', 'no', 'n/a', 'n/a', '0000-00-00'),
(456, 'Patient223', 's0445_re', '56', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(457, 'Patient223', 's0446_re', '56', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(458, 'Patient224', 's0447_re', '38', 'female', 'Valvular heart disease', 'no', 'n/a', 'n/a', '0000-00-00'),
(459, 'Patient225', 's0448_re', '56', 'female', 'Bundle branch block', 'no', 'n/a', 'n/a', '0000-00-00'),
(460, 'Patient226', 's0449_re', '62', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(461, 'Patient227', 's0450_re', '52', 'male', 'Hypertrophy', 'no', 'n/a', 'n/a', '0000-00-00'),
(462, 'Patient228', 's0451_re', '73', 'male', 'Bundle branch block', 'no', 'n/a', 'n/a', '0000-00-00'),
(463, 'Patient229', 's0452_re', '55', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(464, 'Patient229', 's0453_re', '55', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(465, 'Patient230', 's0454_re', '68', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(466, 'Patient231', 's0455_re', '57', 'male', 'Myocardial infarction', 'no', 'n/a', 'n/a', '0000-00-00'),
(467, 'Patient232', 's0456_re', '70', 'female', 'Cardiomyopathy', 'no', 'n/a', 'n/a', '0000-00-00'),
(468, 'Patient233', 's0457_re', '24', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(469, 'Patient233', 's0483_re', '24', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(470, 'Patient233', 's0458_re', '24', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(471, 'Patient233', 's0482_re', '24', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(472, 'Patient233', 's0459_re', '24', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(473, 'Patient234', 's0460_re', '34', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(474, 'Patient235', 's0461_re', '30', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(475, 'Patient236', 's0462_re', '25', 'female', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(476, 'Patient236', 's0463_re', '25', 'female', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(477, 'Patient236', 's0464_re', '25', 'female', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(478, 'Patient237', 's0465_re', '47', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(479, 'Patient238', 's0466_re', '29', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(480, 'Patient239', 's0467_re', '59', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(481, 'Patient240', 's0468_re', '28', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(482, 'Patient241', 's0469_re', '33', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(483, 'Patient241', 's0470_re', '33', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(484, 'Patient242', 's0471_re', '28', 'female', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(485, 'Patient243', 's0472_re', '52', 'female', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(486, 'Patient244', 's0473_re', '44', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(487, 'Patient245', 's0474_re', '30', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(488, 'Patient245', 's0480_re', '30', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(489, 'Patient246', 's0478_re', '54', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(490, 'Patient247', 's0479_re', '48', 'female', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(491, 'Patient248', 's0481_re', '64', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(492, 'Patient249', 's0484_re', '46', 'male', 'Myocarditis', 'no', 'n/a', 'n/a', '0000-00-00'),
(493, 'Patient250', 's0485_re', '53', 'male', 'Hypertrophy', 'no', 'n/a', 'n/a', '0000-00-00'),
(494, 'Patient251', 's0503_re', '40', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(495, 'Patient251', 's0486_re', '40', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(496, 'Patient251', 's0506_re', '40', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(497, 'Patient252', 's0487_re', '54', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(498, 'Patient253', 's0488_re', '62', 'male', 'Cardiomyopathy', 'no', 'n/a', 'n/a', '0000-00-00'),
(499, 'Patient254', 's0489_re', '57', 'male', 'Cardiomyopathy', 'no', 'n/a', 'n/a', '0000-00-00'),
(500, 'Patient255', 's0491_re', '69', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(501, 'Patient256', 's0492_re', '64', 'female', 'Cardiomyopathy', 'no', 'n/a', 'n/a', '0000-00-00'),
(502, 'Patient257', 's0493_re', '68', 'male', 'Cardiomyopathy', 'no', 'n/a', 'n/a', '0000-00-00'),
(503, 'Patient258', 's0494_re', '42', 'male', 'Dysrhythmia', 'no', 'n/a', 'n/a', '0000-00-00'),
(504, 'Patient259', 's0495_re', '58', 'female', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(505, 'Patient260', 's0496_re', 'n/a', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(506, 'Patient261', 's0497_re', '51', 'male', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(507, 'Patient262', 's0498_re', '41', 'female', 'Cardiomyopathy', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(508, 'Patient263', 's0499_re', '37', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(509, 'Patient264', 's0500_re', '45', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(510, 'Patient265', 's0501_re', '57', 'male', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(511, 'Patient266', 's0502_re', '68', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(512, 'Patient267', 's0504_re', '67', 'female', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(513, 'Patient268', 's0505_re', '55', 'male', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(514, 'Patient269', 's0508_re', '61', 'male', 'Myocarditis', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(515, 'Patient270', 's0507_re', '60', 'male', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(516, 'Patient271', 's0509_re', '41', 'male', 'Myocarditis', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(517, 'Patient272', 's0510_re', '61', 'male', 'Myocarditis', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(518, 'Patient273', 's0511_re', '69', 'male', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(519, 'Patient274', 's0512_re', '57', 'male', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(520, 'Patient275', 's0513_re', '48', 'male', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(521, 'Patient276', 's0526_re', 'n/a', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(522, 'Patient277', 's0527_re', 'n/a', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(523, 'Patient278', 's0530_re', '62', 'male', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(524, 'Patient278', 's0528_re', '62', 'male', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(525, 'Patient278', 's0529_re', '62', 'male', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(526, 'Patient279', 's0534_re', '35', 'female', 'Healthy control', 'no', 'n/a', 'n/a', '0000-00-00'),
(527, 'Patient279', 's0531_re', '35', 'female', 'Healthy control', 'no', 'n/a', 'n/a', '0000-00-00'),
(528, 'Patient279', 's0532_re', '35', 'female', 'Healthy control', 'no', 'n/a', 'n/a', '0000-00-00'),
(529, 'Patient279', 's0533_re', '35', 'female', 'Healthy control', 'no', 'n/a', 'n/a', '0000-00-00'),
(530, 'Patient280', 's0535_re', '67', 'male', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(531, 'Patient281', 's0537_re', '68', 'male', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(532, 'Patient282', 's0539_re', '61', 'male', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(533, 'Patient283', 's0542_re', '82', 'male', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(534, 'Patient284', 's0552_re', '48', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(535, 'Patient284', 's0551_re', '48', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(536, 'Patient284', 's0543_re', '48', 'male', 'Healthy control', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(537, 'Patient285', 's0544_re', 'n/a', '', 'n/a', 'n/a', 'n/a', 'n/a', '0000-00-00'),
(538, 'Patient286', 's0546_re', '56', 'male', 'Dysrhythmia', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(539, 'Patient287', 's0547_re', '78', 'female', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(540, 'Patient287', 's0548_re', '78', 'female', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(541, 'Patient288', 's0549_re', '67', 'male', 'Cardiomyopathy', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(542, 'Patient289', 's0550_re', '69', 'female', 'Cardiomyopathy', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(543, 'Patient290', 's0553_re', '60', 'male', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(544, 'Patient291', 's0554_re', '69', 'male', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(545, 'Patient292', 's0556_re', '66', 'male', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(546, 'Patient292', 's0555_re', '66', 'male', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(547, 'Patient293', 's0558_re', '75', 'male', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(548, 'Patient293', 's0557_re', '75', 'male', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(549, 'Patient294', 's0559_re', '61', 'female', 'Myocardial infarction', 'unknown', 'n/a', 'n/a', '0000-00-00'),
(550, 'Patient190', 's0016lr1', '20', 'Female', 'Myocardial infarction', 'yes', '29-Sep-90', 'Heparin Isosorbit-Mononitrate ASA Diazepam', '2004-02-04'),
(551, 'Patient123', 's0016lre', '81', 'Female', 'selamat', 'yes', '02-Oct-90', 'n/a', '2000-03-31'),
(552, 'Patient123', 's0016lre', '20', 'laki_l', 'selamat', 'no', '29-Sep-90', 'Heparin Isosorbit-Mononitrate ASA Diazepam', '2000-03-31');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_pendaftaran`
--

CREATE TABLE `user_pendaftaran` (
  `id_pendaftaran` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `nama_kk` varchar(128) NOT NULL,
  `no_kartu` varchar(128) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `alamat` varchar(128) NOT NULL,
  `status` varchar(128) NOT NULL,
  `tgl_lahir` varchar(128) NOT NULL,
  `umur` varchar(128) NOT NULL,
  `j_kelamin` varchar(128) NOT NULL,
  `keluhan` varchar(200) NOT NULL,
  `tindakan` varchar(128) NOT NULL,
  `poli_tj` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user_pendaftaran`
--

INSERT INTO `user_pendaftaran` (`id_pendaftaran`, `tanggal`, `nama_kk`, `no_kartu`, `nama`, `alamat`, `status`, `tgl_lahir`, `umur`, `j_kelamin`, `keluhan`, `tindakan`, `poli_tj`) VALUES
(25, '2020-11-16', 'Andri', '0100100', 'Billiy', 'Padang Luar', 'Umum', '2020-09-10', '20', 'perempuan', 'Demam', 'Selesai', 'Poli Umum'),
(26, '2020-11-16', 'selamat', '0985', 'andi', 'Padang lua', 'Umum', '2007-02-05', '13', 'laki_laki', 'sakit gigi', 'Selesai', 'Poli Gigi'),
(27, '2020-11-16', 'selamat', '0985', 'andi', 'Padang lua', 'Umum', '2007-02-05', '13', 'laki_laki', 'u', 'Selesai', 'Poli Ibu'),
(28, '2020-11-16', 'wed', '333', 'bubu', 'Padang lua', 'BPJS', '2020-11-17', '20', 'laki_laki', 'qwe', 'Selesai', 'Poli Umum'),
(29, '2024-05-16', 'n/a', 's0007_re', 'Patient146', 'n/a', 'n/a', '', '20', 'n/a', '', 'Selesai', 'Poli Umum'),
(30, '2024-05-16', 'Myocardial infarction', 's0016lr12', 'Patient1900', 'Heparin Isosorbit-Mononitrate ASA Diazepam', 'yes', '2004-02-04', '20', 'Female', 'bengkak', 'Mengantri', 'Poli Umum'),
(31, '2024-05-16', 'selamat', 's0016lre543', 'Patient123423', 'n/a', 'yes', '2000-03-31', '81', 'Female', 'yqh', 'Mengantri', 'Poli Umum'),
(32, '2024-05-16', 'selamat', 's0016lreewe', 'Patient1234', 'Heparin Isosorbit-Mononitrate ASA Diazepam', 'no', '2000-03-31', '20', 'laki_laki', 'yui', 'Mengantri', 'Poli Umum');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL,
  `role` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user_role`
--

INSERT INTO `user_role` (`id`, `role`) VALUES
(1, 'Administrator'),
(2, 'Admin Rumah Sakit'),
(3, 'Petugas Rumah sakit');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_sub_menu`
--

CREATE TABLE `user_sub_menu` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `url` varchar(128) NOT NULL,
  `icon` varchar(128) NOT NULL,
  `is_active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user_sub_menu`
--

INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES
(2, 4, 'My Profile', 'User', 'fa fa-fw fa-users', 1),
(3, 4, 'Edit Profile', 'user/edit', 'fas fa-fw fa-user-edit', 1),
(4, 2, 'Menu Manajemen', 'menu', 'fas fa-fw fa-folder', 1),
(5, 2, 'Submenu Manajemen', 'menu/submenu', 'fas fa-fw fa-folder-open', 1),
(10, 1, 'Hak Akses & Akun', 'admin/role', 'fas fa-fw fa-user-tie', 1),
(12, 4, 'Change Password', 'user/changepassword', 'fas fa-fw fa-key', 1),
(14, 7, 'Pemeriksaan Poli Umum', 'Entry', 'fas fa-pencil-alt', 1),
(15, 7, 'Pemeriksaan Poli Ibu', 'entry/vpoliibu', 'fas fa-pencil-alt', 1),
(16, 7, 'Pemeriksaan Poli Anak', 'entry/vpolianak', 'fas fa-pencil-alt', 1),
(17, 7, 'Pemeriksaan Poli Gigi', 'entry/vpoligigi', 'fas fa-pencil-alt', 1),
(20, 3, 'Beranda', 'Welcome', 'fas fa-fw fa-home', 1),
(22, 10, 'Pendaftaran Baru', 'Rekammedis', 'fas fa-fw fa-user', 1),
(23, 10, 'Kunjungan Ulang', 'rekammedis/datapendaftaran', 'fas fa-fw fa-user', 1),
(24, 0, 'Data Petugas Rumah Sakit', 'admin/data-petugas', 'fas fa-fw fa-user-tie', 1),
(25, 1, 'Data Diagnosa', 'admin/data-diagnosa', 'fas fa-fw fa-user-tie', 1),
(26, 1, 'Petugas Rumah Sakit', 'admin/data-petugas', 'fas fa-fw fa-user-tie', 1);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `data_imunisasi`
--
ALTER TABLE `data_imunisasi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `data_kabe`
--
ALTER TABLE `data_kabe`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `data_poli_anak`
--
ALTER TABLE `data_poli_anak`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `data_poli_gigi`
--
ALTER TABLE `data_poli_gigi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `data_poli_ibu`
--
ALTER TABLE `data_poli_ibu`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `data_poli_umum`
--
ALTER TABLE `data_poli_umum`
  ADD PRIMARY KEY (`id_pu`);

--
-- Indeks untuk tabel `tb_diagnosa`
--
ALTER TABLE `tb_diagnosa`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_petugas`
--
ALTER TABLE `tb_petugas`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_access_menu`
--
ALTER TABLE `user_access_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_menu`
--
ALTER TABLE `user_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_pasien`
--
ALTER TABLE `user_pasien`
  ADD PRIMARY KEY (`id`),
  ADD KEY `no_kartu` (`no_kartu`);

--
-- Indeks untuk tabel `user_pendaftaran`
--
ALTER TABLE `user_pendaftaran`
  ADD PRIMARY KEY (`id_pendaftaran`);

--
-- Indeks untuk tabel `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `data_imunisasi`
--
ALTER TABLE `data_imunisasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `data_kabe`
--
ALTER TABLE `data_kabe`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `data_poli_anak`
--
ALTER TABLE `data_poli_anak`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `data_poli_gigi`
--
ALTER TABLE `data_poli_gigi`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `data_poli_ibu`
--
ALTER TABLE `data_poli_ibu`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `data_poli_umum`
--
ALTER TABLE `data_poli_umum`
  MODIFY `id_pu` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT untuk tabel `tb_diagnosa`
--
ALTER TABLE `tb_diagnosa`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `tb_petugas`
--
ALTER TABLE `tb_petugas`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `user_access_menu`
--
ALTER TABLE `user_access_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `user_menu`
--
ALTER TABLE `user_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `user_pasien`
--
ALTER TABLE `user_pasien`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=553;

--
-- AUTO_INCREMENT untuk tabel `user_pendaftaran`
--
ALTER TABLE `user_pendaftaran`
  MODIFY `id_pendaftaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT untuk tabel `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
